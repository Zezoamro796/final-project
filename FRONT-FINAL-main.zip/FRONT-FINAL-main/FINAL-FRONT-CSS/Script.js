// ============================================================
//  CyberWeave  |  Script.js  — Live dashboard (API-powered)
// ============================================================

/** Fetches fresh stats from the PHP API and updates the DOM */
async function refreshMetrics() {
    try {
        const res  = await fetch('api/stats.php');
        const data = await res.json();

        setEl('stat-attacks',  data.attacks);
        setEl('stat-blocked',  data.blocked);
        setEl('stat-vulns',    String(data.vulns).padStart(2, '0'));
        setEl('stat-progress', data.progress + '%');
        setEl('hero-live-sessions', String(data.live_sessions).padStart(2, '0'));
        setEl('hero-last-sync', data.last_sync);

        // Update trend badges
        const trendEl = document.querySelector('#stat-attacks + .stat-trend');
        if (trendEl && data.attacks_trend !== undefined) {
            const sign = data.attacks_trend >= 0 ? '+' : '';
            trendEl.innerHTML = `<i class="fa-solid fa-arrow-trend-${data.attacks_trend >= 0 ? 'up' : 'down'}"></i> ${sign}${data.attacks_trend}%`;
        }

        // Refresh chart data if chart exists
        if (window.threatChart) {
            await refreshChart();
        }

    } catch (err) {
        // silent fail — keep old values visible
        console.warn('[CyberWeave] Stats fetch failed:', err.message);
    }
}

/** Updates only the chart with fresh time-series data */
async function refreshChart() {
    try {
        const res  = await fetch('api/chart.php');
        const data = await res.json();
        if (data.status !== 'ok' && data.status !== 'fallback') return;

        window.threatChart.data.labels                   = data.labels;
        window.threatChart.data.datasets[0].data         = data.vulnerable;
        window.threatChart.data.datasets[1].data         = data.secure;
        window.threatChart.update('none');   // no animation on auto-refresh
    } catch (err) {
        console.warn('[CyberWeave] Chart fetch failed:', err.message);
    }
}

/** Fetches latest security events and re-renders the events list */
async function refreshEvents() {
    const list = document.getElementById('events-list');
    if (!list) return;

    try {
        const res  = await fetch('api/events.php?limit=5');
        const data = await res.json();
        if (!data.events || data.events.length === 0) return;

        const severityClass = { high:'event-severity-high', medium:'event-severity-medium', low:'event-severity-low', critical:'event-severity-high' };
        const iconMap       = { 'fa-database':'fa-database','fa-cookie-bite':'fa-cookie-bite','fa-code':'fa-code','fa-shield-halved':'fa-shield-halved','fa-user-secret':'fa-user-secret','fa-terminal':'fa-terminal','fa-lock-open':'fa-lock-open','fa-eye':'fa-eye','fa-key':'fa-key','fa-comment-dots':'fa-comment-dots','fa-user-plus':'fa-user-plus','fa-user-check':'fa-user-check' };

        list.innerHTML = data.events.map(ev => {
            const iconClass = iconMap[ev.icon] || 'fa-shield';
            const sevClass  = severityClass[ev.severity] || 'event-severity-low';
            const sevLabel  = ev.severity.charAt(0).toUpperCase() + ev.severity.slice(1);
            return `
            <li class="event-item">
                <div class="event-main">
                    <div class="event-badge"><i class="fa-solid ${iconClass}"></i></div>
                    <div>
                        <div class="event-text-main">${escHtml(ev.event_type)}</div>
                        <div class="event-text-sub">${escHtml(ev.description)}</div>
                    </div>
                </div>
                <div class="event-meta">
                    <span class="${sevClass}">${sevLabel} • ${escHtml(ev.time_label)}</span>
                    <span>${ev.scenario_code ? 'Scenario: ' + escHtml(ev.scenario_code) : ''}</span>
                </div>
            </li>`;
        }).join('');

    } catch (err) {
        console.warn('[CyberWeave] Events fetch failed:', err.message);
    }
}

function setEl(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
}

function escHtml(str) {
    return String(str ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function scrollToThreats() {
    const el = document.getElementById('threat-timeline');
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ---- Initialise on DOM ready ----
document.addEventListener('DOMContentLoaded', async function () {
    const canvas = document.getElementById('threatChart');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');

    const gradVuln = ctx.createLinearGradient(0, 0, 0, 400);
    gradVuln.addColorStop(0, 'rgba(239,68,68,0.5)');
    gradVuln.addColorStop(1, 'rgba(239,68,68,0)');

    const gradSec = ctx.createLinearGradient(0, 0, 0, 400);
    gradSec.addColorStop(0, 'rgba(34,197,94,0.5)');
    gradSec.addColorStop(1, 'rgba(34,197,94,0)');

    // Fetch initial chart data from API
    let chartData = {
        labels:      ['10:00','10:10','10:20','10:30','10:40','10:50','11:00','11:10'],
        vulnerable:  [62,49,71,55,83,44,66,58],
        secure:      [78,82,75,91,70,88,77,93],
    };
    try {
        const res = await fetch('api/chart.php');
        const d   = await res.json();
        if (d.labels) chartData = d;
    } catch (_) {}

    window.threatChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: chartData.labels,
            datasets: [
                {
                    label:            'Vulnerable Environment',
                    data:             chartData.vulnerable,
                    borderColor:      '#ef4444',
                    backgroundColor:  gradVuln,
                    borderWidth:      2,
                    fill:             true,
                    tension:          0.4,
                    pointRadius:      3,
                    pointBackgroundColor: '#ef4444',
                },
                {
                    label:            'Secure Environment',
                    data:             chartData.secure,
                    borderColor:      '#22c55e',
                    backgroundColor:  gradSec,
                    borderWidth:      2,
                    fill:             true,
                    tension:          0.4,
                    pointRadius:      3,
                    pointBackgroundColor: '#22c55e',
                },
            ],
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { color:'#e5e7eb', font:{family:'Inter',size:12}, usePointStyle:true, padding:20 },
                },
                tooltip: {
                    mode:'index', intersect:false,
                    backgroundColor:'rgba(0,0,0,0.8)',
                    titleColor:'#e5e7eb', bodyColor:'#e5e7eb',
                    borderColor:'rgba(255,255,255,0.1)', borderWidth:1, padding:12,
                },
            },
            interaction: { mode:'index', intersect:false },
            scales: {
                x: {
                    grid: { display:false },
                    ticks: { color:'#9ca3af', font:{family:'Inter',size:11} },
                },
                y: {
                    min: 0,
                    grid: { color:'rgba(255,255,255,0.05)', drawBorder:false },
                    ticks: {
                        color:'#9ca3af', font:{family:'Inter',size:11},
                        callback: v => v + ' req/s',
                    },
                },
            },
        },
    });

    // Initial load
    await refreshMetrics();
    await refreshEvents();

    // Auto-refresh every 30 seconds (real data — no need to hammer every 3s)
    setInterval(refreshMetrics, 30_000);
    setInterval(refreshEvents,  60_000);
});