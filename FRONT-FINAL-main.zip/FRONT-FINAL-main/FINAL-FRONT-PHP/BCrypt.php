<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@400;700;900&family=Montserrat:wght@400;800&family=Orbitron:wght@400;900&family=Kanit:wght@400;700&family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="Assets/blog_final.css">
</head>
<body>

<div class="container">
   <div class="blog-container">
            <div class="blog-card">
            <img src="Assets/images/password.gif" alt="data" class="floating-img">
            <div class="card-text">
               <h2 class="blog-title">Database Security: Password Hashing</h2>
            <h2>Why You Should Never Store Passwords in Plaintext</h2>
                <p>Storing user passwords as plaintext is a "security suicide." If your database is ever compromised, every user's account is instantly exposed. To protect users, we must use 
                    <strong>
                        Hashing
                    </strong>
                     but not just any hashing—we need algorithms designed to be slow and secure
                    </p>                

                <h3>Why Plaintext & Old Hashes Fail</h3>
                <ul>
                    <li><strong>Plaintext:</strong> Immediate exposure upon any database breach.</li>
                    <li><strong>Weak Hashes (MD5, SHA1):</strong> These algorithms are too fast. Modern hardware can calculate billions of hashes per second, making "Rainbow Table" attacks trivial</li>
                </ul>

                <h3>The Solution: Salted BCrypt</h3>
                <p>BCrypt is a password hashing function that is specifically designed to be <strong>computationally expensive</strong>. It includes two critical features that make it superior:</p>
                <ol>
                    <li><strong>Salting:</strong> It adds a random string (Salt) to each password before hashing, ensuring that two users with the same password have completely different stored hashes.</li>
                    <li><strong>Work Factor (Cost):</strong> BCrypt allows you to define a "cost" parameter, which artificially slows down the hashing process, making brute-force attacks economically and technically unfeasible.</li>
                </ol>

                

                <h3>Implementation: The Right Way</h3>
                <p>In modern web development, never try to write your own hashing logic. Use built-in framework functions:</p>
                
                <div class="code-container">
                    <strong>// SECURE: Password Hashing with BCrypt (PHP)</strong>
                    <pre><code>// To hash a password:
$hash = password_hash($password, PASSWORD_BCRYPT);

// To verify a password:
if (password_verify($input_password, $stored_hash)) {
    // Access Granted
}</code></pre>
                </div>

                <h3>Key Security Rules</h3>
                <ul>
                    <li><strong>One-Way Only:</strong> Hashing is a one-way process. You cannot "decrypt" a hash back into a password.</li>
                    <li><strong>Adaptive Security:</strong> Increase the "cost" parameter of BCrypt as server hardware becomes faster over the years to keep security levels consistent.</li>
                </ul>

                <div class="field-mission">
                    <h3><i class="fas fa-terminal"></i> Field Mission (CyberWeave Challenge)</h3>
                    <p>In our "Credential Lab," examine the database dump provided. Notice that you cannot see any passwords, only strings of random characters. Try to "crack" these BCrypt hashes using a wordlist tool to see how slow and difficult the process is compared to MD5.</p>
                </div>

            </div>
         </div> 
         <div class="comments-section">
            <h3 class="comments-title"><i class="fas fa-comments"></i> Leave a Comment</h3>
            <form action="#" method="POST" class="comment-form">
                <div class="input-group">
                    <input type="text" name="username" placeholder="Your Username" required>
                    <input type="email" name="email" placeholder="Your Email" required>
                </div>
                <textarea name="comment" rows="6" placeholder="Share your comment" required>

                </textarea>
                <button type="submit" class="send-btn">
                    <i class="fas fa-paper-plane"></i> Send
                </button>
            </form>
        </div>

                <nav class="login-buttons">
            <a href="login.html" class="btn-login"><i class="fas fa-user-graduate"></i> Login</a>
            <a href="CreateAccount.html" class="btn-CreateAccount"><i class="fas fa-user-plus"></i> Create Account</a>
        </nav>

    </body>
    </html>