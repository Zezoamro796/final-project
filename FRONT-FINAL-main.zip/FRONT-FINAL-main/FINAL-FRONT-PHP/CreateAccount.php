<?php
// ============================================================
//  CyberWeave  |  CreateAccount.php  — with PHP backend
// ============================================================
require_once 'config.php';

session_safe_start();
$errors  = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ---- Sanitise & validate inputs ----
    $full_name = trim(strip_tags($_POST['full_name'] ?? ''));
    $email     = trim($_POST['user_email'] ?? '');
    $phone     = trim($_POST['user_phone'] ?? '');
    $age       = (int)($_POST['user_age'] ?? 0);
    $gender    = $_POST['user_gender'] ?? '';
    $city      = $_POST['user_city']   ?? '';
    $password  = $_POST['password']    ?? '';
    $confirm   = $_POST['confirm_password'] ?? '';

    if (empty($full_name) || strlen($full_name) < 3) $errors[] = 'Full name must be at least 3 characters.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))    $errors[] = 'Invalid email address.';
    if (!preg_match('/^01[0-9]{9}$/', $phone))         $errors[] = 'Phone must be a valid Egyptian number (01XXXXXXXXX).';
    if ($age < 10 || $age > 100)                       $errors[] = 'Age must be between 10 and 100.';
    if (!in_array($gender, ['male','female','other']))  $errors[] = 'Please select a valid gender.';
    if (empty($city))                                   $errors[] = 'Please select your city.';
    if (strlen($password) < 8)                          $errors[] = 'Password must be at least 8 characters.';
    if ($password !== $confirm)                         $errors[] = 'Passwords do not match.';

    if (empty($errors)) {
        try {
            $pdo = db_connect();

            // Check duplicate email
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetchColumn()) {
                $errors[] = 'This email address is already registered.';
            } else {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("
                    INSERT INTO users
                        (full_name, email, password_hash, phone, age, gender, city)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([$full_name, $email, $hash, $phone, $age, $gender, $city]);
                $success = true;

                // Log event
                $ev = $pdo->prepare("
                    INSERT INTO security_events (event_type,severity,environment,description,scenario_code,icon)
                    VALUES ('New User Registration','low','secure','A new student account was created.','REG-01','fa-user-plus')
                ");
                $ev->execute();
            }
        } catch (PDOException $e) {
            $errors[] = 'Database error — please try again later.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - CyberWeave</title>
    <link rel="stylesheet" href="Assets/login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400&display=swap" rel="stylesheet">
    <style>
        .alert { padding:12px 16px; border-radius:8px; margin-bottom:14px; font-size:0.85rem; }
        .alert-error   { background:rgba(239,68,68,0.15);  color:#ef4444; border:1px solid rgba(239,68,68,0.3); }
        .alert-success { background:rgba(34,197,94,0.15);  color:#22c55e; border:1px solid rgba(34,197,94,0.3); }
        .alert ul { margin:0; padding-left:18px; }
    </style>
</head>
<body>
    <div class="SignIn-container">
        <form class="SignIn-form" method="POST" action="CreateAccount.php">
            <div class="login-header">
                <h2>Create Account</h2>
                <p>Join our AI-powered cybersecurity platform</p>
            </div>

            <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                Account created successfully! <a href="login.php" style="color:inherit;font-weight:700;">Login here →</a>
            </div>
            <?php elseif (!empty($errors)): ?>
            <div class="alert alert-error">
                <ul>
                    <?php foreach ($errors as $e): ?>
                        <li><?= htmlspecialchars($e) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>

            <div class="input-group">
                <label>Name</label>
                <div class="field-wrapper">
                    <input type="text" name="full_name" placeholder="Full Name"
                           value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>" required>
                    <i class="fa-solid fa-user"></i>
                </div>
            </div>

            <div class="input-group">
                <label>Email</label>
                <div class="field-wrapper">
                    <input type="email" name="user_email" placeholder="XXXXXXXX@gmail.com"
                           value="<?= htmlspecialchars($_POST['user_email'] ?? '') ?>" required>
                    <i class="fa-solid fa-envelope"></i>
                </div>
            </div>

            <div class="input-group">
                <label>Phone Number</label>
                <div class="field-wrapper">
                    <input type="tel" name="user_phone" placeholder="01XXXXXXXXX"
                           value="<?= htmlspecialchars($_POST['user_phone'] ?? '') ?>" required>
                    <i class="fa-solid fa-phone"></i>
                </div>
            </div>

            <div class="row">
                <div class="input-group">
                    <div class="field-wrapper">
                        <input type="number" name="user_age" placeholder="Age" min="10" max="100"
                               value="<?= htmlspecialchars($_POST['user_age'] ?? '') ?>" required>
                        <i class="fa-solid fa-calendar-day"></i>
                    </div>
                </div>
                <div class="input-group">
                    <div class="field-wrapper">
                        <select name="user_gender" required>
                            <option value="" disabled <?= empty($_POST['user_gender']) ? 'selected' : '' ?>>Gender</option>
                            <option value="male"   <?= ($_POST['user_gender'] ?? '') === 'male'   ? 'selected' : '' ?>>Male</option>
                            <option value="female" <?= ($_POST['user_gender'] ?? '') === 'female' ? 'selected' : '' ?>>Female</option>
                        </select>
                        <i class="fa-solid fa-user-tag"></i>
                    </div>
                </div>
            </div>

            <div class="input-group">
                <label>City / Governorate</label>
                <div class="field-wrapper">
                    <select name="user_city" required>
                        <option value="" disabled <?= empty($_POST['user_city']) ? 'selected' : '' ?>>Select your City</option>
                        <?php
                        $cities = ['Damietta','Mansoura','Port Said','Cairo','Giza','Alexandria','Qalyubia','Suez','Ismailia','Sharqia','Gharbia','Kafr El Sheikh','Monufia','Beheira','Fayoum','Beni Suef','Minya','Assiut','Sohag','Qena','Luxor','Aswan','Red Sea','New Valley','Matrouh','North Sinai','South Sinai'];
                        foreach ($cities as $c):
                            $sel = ($_POST['user_city'] ?? '') === $c ? 'selected' : '';
                        ?>
                        <option value="<?= $c ?>" <?= $sel ?>><?= $c ?></option>
                        <?php endforeach; ?>
                    </select>
                    <i class="fa-solid fa-location-dot"></i>
                </div>
            </div>

            <div class="input-group">
                <label>Password</label>
                <div class="field-wrapper">
                    <input type="password" name="password" placeholder="*********" id="u_pass" required>
                    <i class="fa-solid fa-eye-slash toggle-password"></i>
                </div>
            </div>

            <div class="input-group">
                <label>Confirm Password</label>
                <div class="field-wrapper">
                    <input type="password" name="confirm_password" placeholder="*********" id="u_confirm" required>
                    <i class="fa-solid fa-eye-slash toggle-password"></i>
                </div>
            </div>

            <button type="submit" class="signup-btn">
                <span>Create Account</span>
                <i class="fa-solid fa-arrow-right"></i>
            </button>
            <p class="login-link">
                Already have an account? <a href="login.php">Login here</a>
            </p>
        </form>
    </div>

    <script src="Assets/CreateAccount.js"></script>
</body>
</html>