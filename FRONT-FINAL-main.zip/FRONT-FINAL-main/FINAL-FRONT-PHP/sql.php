<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CyberWeave | Secure Learning</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@400;700;900&family=Montserrat:wght@400;800&family=Orbitron:wght@400;900&family=Kanit:wght@400;700&family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="Assets/blog_final.css">
</head>
<body>
 <div class="container">
   <div class="blog-container">
        <div class="blog-card">
            <img src="Assets/images/SQL.gif" alt="SQL Injection" class="floating-img">
            <div class="card-text">
                <h2 class="blog-title">SQL Injection</h2>
                <h2>SQL Injection: How a Single Character Can Destroy Your Database</h2>
<p>In the cybersecurity world, some vulnerabilities require days of meticulous planning, while others are frighteningly simple—where a single character, like a single quote ('), can open the gates of hell. Today, we’re diving into the most notorious vulnerability in web history: <strong>SQL Injection (SQLi)</strong>.</p>
<h3>What is SQL Injection (SQLi)?</h3>
<p>At its core, SQLi is an attack technique where a malicious actor "injects" rogue SQL code into input fields (such as login forms or search bars), forcing the backend database to execute that code.</p>
<p>Instead of asking the database, "Is this password correct?", the application finds itself executing a command that says: "Dump all user credentials to this unauthorized user."</p>
<h3>How the "Injection" Happens (The Dark Side)</h3>
<p>Imagine a simple, vulnerable PHP snippet:</p>
<div class="code-container">
    <p class="code-heder">Vulnerable PHP Code</p>
    <pre><code>$username = $_POST['username'];
$query = "SELECT * FROM users WHERE username = '$username'";</code></pre>
</div>

<p>The developer placed the <code>$username</code> variable directly into the query. What if an attacker enters this into the username field? <code>' OR '1'='1</code></p>

<p>The resulting query sent to the database becomes:</p>

<div class="code-container">
    <pre>
        <code>SELECT * FROM users WHERE username = '' OR '1'='1'</code>
    </pre>
</div>

<p>Since <code>'1'='1'</code> is always TRUE, the database returns every record in the table, effectively bypassing the password verification entirely!</p>
<h3>Why Does It Succeed?</h3>
<p>It succeeds because of <strong>Blind Trust</strong>. The developer assumed the user would only input a "name" and never anticipated that the user might input "programming commands."</p>
<h3>How to Defend Your Code (The Proactive Approach)</h3>
<p>In our blog, we learn to attack so we can build an impenetrable defense. The solution isn't complex; it’s called <strong>Prepared Statements</strong> (or Parameterized Queries).</p>
<p>Essentially, we tell the database: "This part is the logic (query), and this part (the user input) is strictly data (text). Never execute it." This way, if an attacker types <code>OR 1=1</code>,
 the database treats it as just a literal username, and the command is never executed.</p>
<h3>Field Mission (CyberWeave Challenge)</h3>
<p><em>Disclaimer: Never attempt this on real-world sites; it is illegal. Use our educational environment only.</em></p>
            </div>
        </div>

<div class="comments-section">
            <h3 class="comments-title"><i class="fas fa-comments"></i> Leave a Comment</h3>
            <form action="#" method="POST" class="comment-form">
                <div class="input-group">
                    <input type="text" name="username" placeholder="Your Username" required>
                    <input type="email" name="email" placeholder="Your Email" required>
                </div>
                <textarea name="comment" rows="4" placeholder="Share your comment" required></textarea>
                <button type="submit" class="send-btn">
                    <i class="fas fa-paper-plane"></i> Send
                </button>
            </form>
        </div>
        <nav class="login-buttons">
            <a href="login.html" class="btn-login"><i class="fas fa-user-graduate"></i> Login</a>
            <a href="CreateAccount.html" class="btn-CreateAccount"><i class="fas fa-user-plus"></i> Create Account</a>
        </nav>
    </nav>
</body>