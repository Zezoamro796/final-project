<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CyberWeave | Secure Learning</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;800&family=Orbitron:wght@900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
     <link rel="stylesheet" href="Assets/style-first-page.css">
</head>
<body>

    <header>
<div class="logo-container">
        <img src="Assets/Images/logo.png" alt="CyberWeave Logo" class="logo-img">
        <a href="index.html" class="logo-text">
            <span class="cyber">Cyber</span><span class="weave">Weave</span>
        </a>
        </div>

<div class="menu-container">
    <button class=" Explore-btn" onclick="toggleMenu()">
        <span class="btn-content">
            <i class="fas fa-compass"></i> Explore
        </span>
        <i class="fas fa-chevron-down arrow-icon"></i> </button>
    
<nav id="nav-menu" class="Explore-menu">
    <ul>
        <li><a href="about.php">About</a></li>
        <li><a href="why-choose.php">why choose CyberWeave</a></li>
        <li><a href="services.php">Services</a></li>
        <li><a href="dashboard.php">dashboard</a></li>
        <li><a href="products.php">Products</a></li>
        <li><a href="contact.php">Contact</a></li>

    </ul>
</nav>
</div>

    </header>
    

<main>
    <section class="hero-new">
        <div class="hero-text">
            <h2>Secure Web Application <br>for Cybersecurity Training</h2>
            <p>An educational cybersecurity platform that compares vulnerable and secure implementations 
            <br>of web applications enhanced with AI-based threat detection and attack monitoring mechanisms</p>
            
<a href="blog.html">
    <button class="btn-red">Launch Vulnerable Environment</button>
</a>

<a href="blog-Secure.html">
    <button class="btn-blue">Launch Secure Environment</button>
</a>

<a href="Tutorial .html" class="video-tutorial">
        <i class="fas fa-video"></i>
        <span>Watch Full Tutorial Playlist</span>
    </a>
        </div> 
    </section>
 </main>

<script>
    function toggleMenu() {
        const menu = document.getElementById('nav-menu');
        const arrow = document.querySelector('.arrow-icon');
        
        menu.classList.toggle('show');
        
        if (menu.classList.contains('show')) {
            arrow.style.transform = "rotate(180deg)";
        } else {
            arrow.style.transform = "rotate(0deg)";
        }
    }

    window.onclick = function(event) {
        const menu = document.getElementById('nav-menu');
        const button = document.querySelector('.Explore-btn');
        
        if (!button.contains(event.target) && !menu.contains(event.target)) {
            menu.classList.remove('show');
            document.querySelector('.arrow-icon').style.transform = "rotate(0deg)";
        }
    }
</script>

</body>
</html>

