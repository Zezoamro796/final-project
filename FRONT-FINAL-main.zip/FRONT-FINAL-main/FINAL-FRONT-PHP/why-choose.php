<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="Assets/why-choose.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;800&family=Orbitron:wght@400;700;900&display=swap" rel="stylesheet">

    </head>
<body>


    <main>
        <section class="hero-new">
            <div class="hero-text">
                </div> 
        </section> 

        <section class="features-section">
<h2 class="section-title">
    Why Choose <span class="highlight">CyberWeave</span>?
</h2>            
<p class="section-desc">Your journey to becoming a security expert starts here</p>
            
            <div class="cards-container">
                <div class="feature-card">
                    <i class="fas fa-microchip"></i>
                    <h3>Advanced AI Analysis</h3>
                    <p>Leverage cutting-edge AI for real-time threat detection and behavior monitoring.</p>
                </div>
                
                <div class="feature-card">
                    <i class="fas fa-shield-halved"></i>
                    <h3>Secure Sandbox</h3>
                    <p>Practice in a completely isolated and safe environment designed for risk-free learning.</p>
                </div>
                
                <div class="feature-card">
                    <i class="fas fa-code-compare"></i>
                    <h3>Vulnerability Comparison</h3>
                    <p>Analyze side-by-side differences between vulnerable code and secure implementations.</p>
                </div>
            </div>
        </section>

    </main> 
</body>
</html>