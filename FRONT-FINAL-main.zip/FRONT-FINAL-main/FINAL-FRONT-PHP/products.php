<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Products | SecureWeb</title>
    <link rel="stylesheet" href="Assets/style-products.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@700&display=swap" rel="stylesheet">
       <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;800&family=Orbitron:wght@400;700;900&display=swap" rel="stylesheet">

</head>

<body>

    <header>
        <h1>Premium Products</h1>
        <p>Advanced security tools and AI-enhanced scripts for your infrastructure</p>
    </header>

    <div class="container">
        <div class="product-grid">

            <div class="product-card">
    <div class="status">Active</div>
    <img src="Assets/images/Vulnerability Scanner v2.0.png" alt="Vulnerability Scanner">
    <h3>Secure Authentication Module</h3>
    <p>An automated scanning framework designed to detect SQLi, XSS, and CSRF 
        vulnerabilities across 
        your web applications in real-time</p>
    <div class="product-price">$149.00</div>
<button type="button">
    <i class="fas fa-shopping-cart"></i> Purchase License
</button>
</div>
            
   <div class="product-card">
    <div class="status">Analyzing</div>
    <img src="Assets/images/AI Log Analyzer.png" alt="AI Log Analyzer">
    <h3>AI Log Analyzer</h3>
    <p>Integrate Artificial Intelligence into your server logs. 
        This tool instantly identifies malicious patterns and blocks suspicious IP addresses</p>
    <div class="product-price">$299.00</div>
<button type="button">
    <i class="fas fa-shopping-cart"></i> Purchase License
</button>
</div>

<div class="product-card">
    <div class="status">Active</div>
    <img src="Assets/images/Secure Authentication Module.png" alt="Secure Auth">
    <h3>Secure Authentication Module</h3>
    <p>A highly secure PHP login system featuring 2FA, 
        biometric web-auth support, 
        and brute-force protection out of the box.</p>
    <div class="product-price">$89.00</div>
<button type="button">
    <i class="fas fa-shopping-cart"></i> Purchase License
</button>
    
</div>

</body>
</html>