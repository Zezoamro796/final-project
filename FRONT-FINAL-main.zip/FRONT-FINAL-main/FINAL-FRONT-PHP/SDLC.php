<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@400;700;900&family=Montserrat:wght@400;800&family=Orbitron:wght@400;900&family=Kanit:wght@400;700&family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="Assets/blog_final.css">
</head>
<body>

<div class="container">
   <div class="blog-container">
            <div class="blog-card">
            <img src="Assets/images/SDLC.gif" alt="Secure SDLC" class="floating-img">
            <div class="card-text">
               <h2 class="blog-title">Secure SDLC</h2>
            <h2>Integrating Security into Every Stage of Coding</h2>
                <p>Most developers treat security as a "bolt-on" feature—something to check right before releasing. 
                    However, the Secure SDLC (Software Development Life Cycle) approach embeds security into the very 
                    DNA of your project, 
                    reducing costs and preventing vulnerabilities before they are even written.</p>
                <h3>The Phases of Secure SDLC</h3>
                <ol>
                    <li><strong>Planning (Security Requirements):</strong> Identify potential threats. Who are the users? What are the most valuable data points?</li>
                    <li><strong>Design (Threat Modeling):</strong> Visualize your application's architecture to find "logical gaps" before writing a single line of code.</li>
                    <li><strong>Development (Secure Coding):</strong> Use standardized libraries and follow secure coding patterns (like Prepared Statements).</li>
                    <li><strong>Testing (Automated Scans):</strong> Use DAST (Dynamic) and SAST (Static) tools to scan your code automatically for vulnerabilities.</li>
                    <li><strong>Deployment (Monitoring):</strong> Real-time logging and incident response to detect and react to attacks as they happen.</li>
                </ol>
                <h3>Why Shift Left?</h3>
                <p>"Shifting Left" means moving security testing as early as possible in the development process. Fixing a bug during the design phase costs significantly less than fixing it after the software has been deployed to production.</p>

                <h3>Key Pillars for Success</h3>
                <ul>
                    <li><strong>Security Training:</strong> A team that understands common vulnerabilities (OWASP Top 10) is your strongest defense.</li>
                    <li><strong>Automated Tooling:</strong> Integrate security linters and scanners directly into your Git CI/CD pipelines.</li>
                    <li><strong>Code Reviews:</strong> Peer reviews shouldn't just focus on functionality; they must include a mandatory "security check" checklist.</li>
                </ul>

                <div class="field-mission">
                    <h3> Field Mission (CyberWeave Challenge)</h3>
                    <p>In our "Pipeline Lab," try to push a code update that contains a hardcoded API key. Watch as our automated security gate catches the vulnerability and blocks the build, forcing you to use an environment variable instead.</p>
                </div>

            </div>
         </div> 
         <div class="comments-section">
            <h3 class="comments-title"><i class="fas fa-comments"></i> Leave a Comment</h3>
            <form action="#" method="POST" class="comment-form">
                <div class="input-group">
                    <input type="text" name="username" placeholder="Your Username" required>
                    <input type="email" name="email" placeholder="Your Email" required>
                </div>
                <textarea name="comment" rows="6" placeholder="Share your comment" required>

                </textarea>
                <button type="submit" class="send-btn">
                    <i class="fas fa-paper-plane"></i> Send
                </button>
            </form>
        </div>

                <nav class="login-buttons">
            <a href="login.html" class="btn-login"><i class="fas fa-user-graduate"></i> Login</a>
            <a href="CreateAccount.html" class="btn-CreateAccount"><i class="fas fa-user-plus"></i> Create Account</a>
        </nav>

    </body>
    </html>