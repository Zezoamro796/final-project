<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@400;700;900&family=Montserrat:wght@400;800&family=Orbitron:wght@400;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="Assets/blog_final.css">
</head>
<body>
<main class="container">
    <div class="blog-container">
            <div class="blog-card">
            <img src="Assets/images/IDOR.gif" alt="IDOR" class="floating-img">
            <div class="card-text">
                <h2 class="blog-title">IDOR</h2>
                <h2>The Hidden Vulnerability</h2>
                <p>In the landscape of web security, some vulnerabilities require complex exploits. Others, like IDOR, are frighteningly simple: they exist because of a lack of proper access control. IDOR occurs when an application exposes a reference to an internal implementation object—such as a file, database record, or user profile—without verifying that the current user is authorized to access it.</p>
                <h3>The Mechanism of IDOR</h3>
                <p>An IDOR vulnerability typically surfaces when a web application uses a direct database key or identifier to fetch data.</p>
<p>For example, if you visit your profile page, your URL might look like this:</p>
<div class="code-container">
    <pre>
        <code>https://cyberweave.com/api/user/1234</code>
    </pre>
</div>
                <p>If you are a curious user, you might change the ID to <strong>1235</strong>. If the server returns someone else's private data, the application is vulnerable. The server assumes that because you provided a valid ID, you must be the owner of that object.</p>
                <h3>Why Does IDOR Happen?</h3>
                <p>The root cause is "The Myth of Obscurity." Developers often believe that if an ID is long or random, users won't know how to access other objects. However, security should never rely on obscurity. If the server does not perform an <strong>Authorization Check</strong>, the vulnerability exists.</p>
                <h3>The Impact</h3>

                <ul>
                    <li><strong>Exposure of Private Records:</strong> Unauthorized access to profiles, medical records, or financial statements.</li>
                    <li><strong>Modification of Data:</strong> Attackers can use PUT/POST requests to modify records they shouldn't access.</li>
                    <li><strong>Mass Data Scraping:</strong> Attackers can iterate through sequential IDs to dump entire databases.</li>
                </ul>

                <h3>How to Prevent IDOR</h3>
                <p>To build a "Secure Environment," move away from trusting user-provided identifiers:</p>
                <ol>
                    <li><strong>Enforce Server-Side Access Control:</strong> The server must verify that the session user has permission to interact with that specific object ID.</li>
                    <li><strong>Use Indirect References:</strong> Instead of exposing database primary keys, use Randomized UUIDs or session-based tokens.</li>
                    <li><strong>Default to Deny:</strong> Assume no user has access to any object until explicitly granted.</li>
                </ol>                
            </div>
            </div>


         <div class="comments-section">
            <h3 class="comments-title"><i class="fas fa-comments"></i> Leave a Comment</h3>
            <form action="#" method="POST" class="comment-form">
                <div class="input-group">
                    <input type="text" name="username" placeholder="Your Username" required>
                    <input type="email" name="email" placeholder="Your Email" required>
                </div>
                <textarea name="comment" rows="6" placeholder="Share your comment" required>

                </textarea>
                <button type="submit" class="send-btn">
                    <i class="fas fa-paper-plane"></i> Send
                </button>
            </form>
        </div>

                <nav class="login-buttons">
            <a href="login.html" class="btn-login"><i class="fas fa-user-graduate"></i> Login</a>
            <a href="CreateAccount.html" class="btn-CreateAccount"><i class="fas fa-user-plus"></i> Create Account</a>
        </nav>

</body>
</html>