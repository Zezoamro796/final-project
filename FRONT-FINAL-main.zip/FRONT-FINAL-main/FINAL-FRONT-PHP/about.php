<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us | SecureWeb</title>
    <link rel="stylesheet" href="Assets/style-about.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400&display=swap" rel="stylesheet">
   <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;800&family=Orbitron:wght@400;700;900&display=swap" rel="stylesheet">
    </head>
        <body class="dark-theme">
    <header class="header-section">
        <div class="header-content">
            <h1>About SecureWeb</h1>
            <p>Discover our mission, vision, and the elite team behind our security solutions</p>
        </div>
    </header>

    <div class="container">
        <div class="About-container">
            
            <div class="About-card">
               <img src="Assets/images/Who We Are.png" alt="Who We Are" class="floating-img">
                <div class="card-text">
                    <h2>Who We Are</h2>
                    <p>We are a dedicated team of cybersecurity experts, ethical hackers, and AI developers. 
                    With years of experience in securing digital infrastructures, 
                    we specialize in providing top-tier web security and advanced intelligence integrations 
                    to keep your data safe from modern cyber threats.</p>
                </div>
            </div>

            <div class="About-card">
               <img src="Assets/images/Our Mission.png" alt="Our Mission" class="floating-img">
                <div class="card-text">
                    <h2>Our Mission</h2>
                    <p>Our mission is to empower businesses by fortifying their online presence. 
                        We believe that privacy and security are fundamental rights, and we strive 
                        to deliver unbreachable web solutions, automated vulnerability assessments, and proactive defense mechanisms.</p>
                </div>
            </div>

            <div class="About-card">
               <img src="Assets/images/Why Choose Us.png" alt="Why Choose Us?" class="floating-img">
                <div class="card-text">
                    <h2>Why Choose Us</h2>
                    <p>Unlike traditional development teams, 
                    we build with security embedded at the core. 
                    From utilizing robust encryption protocols to implementing AI-driven threat detection,
                     we ensure that your digital assets remain impenetrable against zero-day exploits and sophisticated attacks.</p>
                </div>
            </div>

        </div>
    </div>

</body>
</html>