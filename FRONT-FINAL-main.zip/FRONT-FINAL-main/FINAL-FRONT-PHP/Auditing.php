<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@400;700;900&family=Montserrat:wght@400;800&family=Orbitron:wght@400;900&family=Kanit:wght@400;700&family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="Assets/blog_final.css">
</head>
<body>

<div class="container">
   <div class="blog-container">
            <div class="blog-card">
            <img src="Assets/images/Auditing.gif" alt="Security Auditing" class="floating-img">
            <div class="card-text">
               <h2 class="blog-title">Security Auditing</h2>
            <h2>How to Audit Your Code Before Attackers Find the Flaws</h2>
                
                <p>Security is not a destination; it's a journey. Even with perfect initial code, new vulnerabilities (CVEs) are discovered every day. Regular auditing ensures that your "walls" stay strong against modern threats.</p>

                

                <h3>The Two Pillars of Auditing</h3>
                <ul>
                    <li><strong>SAST (Static Application Security Testing):</strong> This is "white-box" testing. Tools scan your source code (without running it) to find dangerous patterns like hardcoded credentials, buffer overflows, or improper SQL handling.</li>
                    <li><strong>DAST (Dynamic Application Security Testing):</strong> This is "black-box" testing. Tools interact with your running application as an external attacker would, sending payloads (like SQLi or XSS) to see how the application reacts.</li>
                </ul>

                <h3>The Manual Audit Checklist</h3>
                <p>Automated tools are great, but human intuition is irreplaceable. When auditing your own code, ask these questions:</p>
                <ol>
                    <li><strong>Data Entry:</strong> Is every user input validated, sanitized, and encoded?</li>
                    <li><strong>Access Control:</strong> Can I access a resource by simply changing an ID in the URL? (IDOR check).</li>
                    <li><strong>Dependency Health:</strong> Are the third-party libraries (e.g., NPM packages) outdated or vulnerable?</li>
                    <li><strong>Logging & Monitoring:</strong> If an attack happens, does the system record enough data to help me understand what occurred?</li>
                </ol>

                

                <h3>Continuous Auditing Strategy</h3>
                <p>Don't wait for a quarterly "big review." Integrate security audits into your workflow:</p>
                <ul>
                    <li><strong>Git Hooks:</strong> Automatically block commits that contain secrets or keys.</li>
                    <li><strong>Dependency Scanners:</strong> Use tools like <code>npm audit</code> or <code>Snyk</code> to automatically flag outdated libraries.</li>
                    <li><strong>Threat Modeling:</strong> Re-visit your architecture design whenever you introduce a major new feature.</li>
                </ul>

                <div class="field-mission">
                    <h3></i> Field Mission (CyberWeave Challenge)</h3>
                    <p>In our "Audit Lab," we have provided a repository with three hidden vulnerabilities. Use the command-line tools provided to scan the codebase. Can you identify all three flaws and document a patch for each before the time runs out?</p>
                </div>

            </div>
         </div> 
         <div class="comments-section">
            <h3 class="comments-title"><i class="fas fa-comments"></i> Leave a Comment</h3>
            <form action="#" method="POST" class="comment-form">
                <div class="input-group">
                    <input type="text" name="username" placeholder="Your Username" required>
                    <input type="email" name="email" placeholder="Your Email" required>
                </div>
                <textarea name="comment" rows="6" placeholder="Share your comment" required>

                </textarea>
                <button type="submit" class="send-btn">
                    <i class="fas fa-paper-plane"></i> Send
                </button>
            </form>
        </div>

                <nav class="login-buttons">
            <a href="login.html" class="btn-login"><i class="fas fa-user-graduate"></i> Login</a>
            <a href="CreateAccount.html" class="btn-CreateAccount"><i class="fas fa-user-plus"></i> Create Account</a>
        </nav>

    </body>
    </html>