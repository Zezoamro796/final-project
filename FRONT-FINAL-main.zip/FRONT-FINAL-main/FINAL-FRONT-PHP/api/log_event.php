<?php
// ============================================================
//  CyberWeave API  |  POST /api/log_event.php
//  Logs a new security event (called when blog pages are visited)
//  Also handles visit tracking for page_visits table
// ============================================================
require_once __DIR__ . '/../config.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit(0); }

$method = $_SERVER['REQUEST_METHOD'];

// ---- GET: track a page visit (called via beacon/fetch from blog pages) ----
if ($method === 'GET') {
    session_safe_start();
    $page = isset($_GET['page']) ? preg_replace('/[^a-zA-Z0-9_\-.]/', '', $_GET['page']) : 'unknown';
    try {
        $pdo  = db_connect();
        $uid  = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;
        $stmt = $pdo->prepare("INSERT INTO page_visits (user_id, page_name, ip_address) VALUES (?,?,?)");
        $stmt->execute([$uid, $page, $_SERVER['REMOTE_ADDR'] ?? null]);
        json_response(['status' => 'tracked', 'page' => $page]);
    } catch (PDOException $e) {
        json_response(['status' => 'error', 'error' => $e->getMessage()], 500);
    }
}

// ---- POST: log a security event ----
if ($method === 'POST') {
    $body = json_decode(file_get_contents('php://input'), true) ?? $_POST;

    $allowed_types = [
        'SQL Injection','XSS','CSRF','IDOR','Command Injection',
        'Broken Authentication','Sensitive Data Exposure','API Key Leak',
        'Session Hijacking','Brute Force','Path Traversal','PoLP Violation'
    ];
    $allowed_sev  = ['low','medium','high','critical'];
    $allowed_env  = ['vulnerable','secure','both'];

    $event_type  = in_array($body['event_type']  ?? '', $allowed_types) ? $body['event_type']  : 'SQL Injection';
    $severity    = in_array($body['severity']    ?? '', $allowed_sev)   ? $body['severity']    : 'medium';
    $environment = in_array($body['environment'] ?? '', $allowed_env)   ? $body['environment'] : 'both';
    $description = substr(strip_tags($body['description'] ?? ''), 0, 500);
    $scenario    = preg_replace('/[^A-Za-z0-9\-]/', '', $body['scenario_code'] ?? '');
    $icon        = preg_replace('/[^a-z0-9\-]/', '', $body['icon'] ?? 'fa-shield');

    try {
        $pdo  = db_connect();
        $stmt = $pdo->prepare("
            INSERT INTO security_events
                (event_type, severity, environment, description, scenario_code, icon)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$event_type, $severity, $environment, $description, $scenario, $icon]);
        json_response(['status' => 'logged', 'id' => $pdo->lastInsertId()]);
    } catch (PDOException $e) {
        json_response(['status' => 'error', 'error' => $e->getMessage()], 500);
    }
}

json_response(['status' => 'invalid_method'], 405);
