<?php
// ============================================================
//  CyberWeave API  |  GET /api/events.php
//  Returns the latest security events for the dashboard feed
// ============================================================
require_once __DIR__ . '/../config.php';

header('Access-Control-Allow-Origin: *');

$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
$limit = max(1, min(50, $limit)); // clamp 1-50

try {
    $pdo = db_connect();

    $stmt = $pdo->prepare("
        SELECT
            id,
            event_type,
            severity,
            environment,
            description,
            scenario_code,
            icon,
            created_at,
            TIMESTAMPDIFF(MINUTE, created_at, NOW()) AS minutes_ago
        FROM security_events
        ORDER BY created_at DESC
        LIMIT :lim
    ");
    $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
    $stmt->execute();
    $events = $stmt->fetchAll();

    // Humanise the "time ago" field
    foreach ($events as &$ev) {
        $m = (int)$ev['minutes_ago'];
        if ($m < 1)       $ev['time_label'] = 'just now';
        elseif ($m < 60)  $ev['time_label'] = "{$m} min ago";
        elseif ($m < 1440){
            $h = intdiv($m, 60);
            $ev['time_label'] = "{$h} hr ago";
        } else {
            $d = intdiv($m, 1440);
            $ev['time_label'] = "{$d} day" . ($d > 1 ? 's' : '') . " ago";
        }
        unset($ev['minutes_ago']);
    }
    unset($ev);

    json_response(['events' => $events, 'count' => count($events), 'status' => 'ok']);

} catch (PDOException $e) {
    json_response(['events' => [], 'count' => 0, 'status' => 'error', 'error' => $e->getMessage()], 500);
}
