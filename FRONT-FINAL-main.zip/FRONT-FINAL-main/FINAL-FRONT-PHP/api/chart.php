<?php
// ============================================================
//  CyberWeave API  |  GET /api/chart.php
//  Returns time-series data for the Attack Timeline chart
// ============================================================
require_once __DIR__ . '/../config.php';

header('Access-Control-Allow-Origin: *');

try {
    $pdo = db_connect();

    // Fetch last 8 time intervals, grouped by label and environment
    $stmt = $pdo->query("
        SELECT
            interval_label,
            environment,
            ROUND(AVG(requests_count)) AS avg_requests
        FROM attack_logs
        WHERE recorded_at >= NOW() - INTERVAL 24 HOUR
        GROUP BY interval_label, environment
        ORDER BY MIN(recorded_at) ASC
        LIMIT 16
    ");
    $rows = $stmt->fetchAll();

    // Build structured arrays for Chart.js
    $labels      = [];
    $vulnerable  = [];
    $secure      = [];

    // Index by label first
    $indexed = [];
    foreach ($rows as $row) {
        $lbl = $row['interval_label'];
        if (!isset($indexed[$lbl])) {
            $indexed[$lbl] = ['vulnerable' => null, 'secure' => null];
        }
        $indexed[$lbl][$row['environment']] = (int)$row['avg_requests'];
    }

    foreach ($indexed as $lbl => $vals) {
        $labels[]     = $lbl;
        $vulnerable[] = $vals['vulnerable'] ?? 0;
        $secure[]     = $vals['secure']     ?? 0;
    }

    // Ensure we always return exactly 8 data points
    // If DB has fewer, pad with recent random-ish values
    while (count($labels) < 8) {
        $t = date('H:i', strtotime('-' . (8 - count($labels)) . ' minutes'));
        $labels[]     = $t;
        $vulnerable[] = rand(40, 75);
        $secure[]     = rand(70, 95);
    }
    $labels     = array_slice($labels,    -8);
    $vulnerable = array_slice($vulnerable, -8);
    $secure     = array_slice($secure,     -8);

    json_response([
        'labels'      => $labels,
        'vulnerable'  => $vulnerable,
        'secure'      => $secure,
        'status'      => 'ok',
    ]);

} catch (PDOException $e) {
    // Fallback: return realistic demo data
    $now = time();
    $labels = [];
    for ($i = 7; $i >= 0; $i--) {
        $labels[] = date('H:i', $now - $i * 600);
    }
    json_response([
        'labels'     => $labels,
        'vulnerable' => [62,49,71,55,83,44,66,58],
        'secure'     => [78,82,75,91,70,88,77,93],
        'status'     => 'fallback',
        'error'      => $e->getMessage(),
    ]);
}
