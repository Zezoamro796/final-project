    <!DOCTYPE html>
    <html lang="en" dir="ltr">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Our Services</title>
        <link rel="stylesheet" href="Assets/style-services.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400&display=swap" rel="stylesheet">
     <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;800&family=Orbitron:wght@400;700;900&display=swap" rel="stylesheet">

    </head>
    
    <body>

        <header class="header-section">
        <div class="header-content">
            <h1>Our Premium Services</h1>
            <p>Providing the best technical and software solutions</p>
        </header>

        <div class="container">
            <div class="services-grid">
   <div class="service-card">
    <img src="Assets/images/web.png" alt="Web Development" class="floating-img">
    <h3>Web Development</h3>
    <p>We build fast, secure, and responsive websites using the latest technologies to help your business grow</p>
    </div>
    
 <div class="service-card">
    <img src="Assets/images/secure.png" alt="Cybersecurity" class="floating-img">
    <h3>Cybersecurity</h3>
    <p>Testing and protecting your web applications from vulnerabilities and breaches (Enhancing your SecureWebProject)</p>
</div>
    
 <div class="service-card">
    <img src="Assets/images/AI.png" alt="AI Applications" class="floating-img">
    <h3>AI Applications</h3>
    <p>Integrating Artificial Intelligence tools into your projects to improve user experience and automate tasks.</p>
</div>
    </body>

    </html>