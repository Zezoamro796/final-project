<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@400;700;900&family=Montserrat:wght@400;800&family=Orbitron:wght@400;900&family=Kanit:wght@400;700&family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="Assets/blog_final.css">
</head>
<body>

<div class="container">
   <div class="blog-container">
            <div class="blog-card">
            <img src="Assets/images/Validation.gif" alt="data" class="floating-img">
            <div class="card-text">
               <h2 class="blog-title">Input Validation</h2>
            <h2>Never Trust Anyone: The Source-Based Sanitization Strategy</h2>
                <p>In the world of web security, the golden rule is simple yet profound: <strong>"Never Trust the User."</strong> Every piece of data sent from a client to your server is a potential weapon. Input Validation is your first line of defense against XSS (Cross-Site Scripting) and other injection attacks.</p>
                <h3>What is Input Validation?</h3>

                <p>Input validation is the process of ensuring that the data received by your application conforms to expected formats, lengths, and types before it is ever processed. If the data looks suspicious, it should be rejected immediately.</p>
                
                <h3>The Strategy: Defense in Depth</h3>
                <p>To fully secure your application against XSS, you must implement a multi-layered approach:</p>
                <ul>
                    <li><strong>Allow-listing (Whitelisting):</strong> Only accept data that matches a known safe pattern (e.g., allow only letters in a name field).</li>
                    <li><strong>Sanitization:</strong> If you must accept complex input (like comments), strip out dangerous HTML tags (e.g., <code>&lt;script&gt;</code>, <code>&lt;iframe&gt;</code>) using trusted libraries.</li>
                    <li><strong>Output Encoding:</strong> The final and most critical step. Convert special characters into their HTML entities (e.g., convert <code>&lt;</code> to <code>&amp;lt;</code>) right before rendering them in the browser.</li>
                </ul>

                <h3>The "Golden" Practice</h3>
                <p>Never rely solely on client-side validation (JavaScript). An attacker can easily bypass browser checks using tools like Burp Suite. <strong>Always perform validation on the server side.</strong></p>
               <div class="code-container">
                    <strong>// SECURE: Example of Output Encoding (PHP)</strong>
                    <pre>
                        <code>
                            // Instead of echoing directly: echo $user_comment;
// Use htmlspecialchars to safely render the content:
echo htmlspecialchars($user_comment, ENT_QUOTES, 'UTF-8');
</code>
</pre>
                </div>

                <h3>Why This Stops XSS</h3>
                <p>When you encode output, the browser stops interpreting the user's input as executable code. Even if an attacker successfully submits 
                <code>
                    &lt;
                    script
                    &gt;
                    alert('XSS')
                    &lt;
                    script
                    &gt;

                </code>
                the browser will display it as harmless text rather than running the malicious script.</p>
            </div>
         </div> 
         <div class="comments-section">
            <h3 class="comments-title"><i class="fas fa-comments"></i> Leave a Comment</h3>
            <form action="#" method="POST" class="comment-form">
                <div class="input-group">
                    <input type="text" name="username" placeholder="Your Username" required>
                    <input type="email" name="email" placeholder="Your Email" required>
                </div>
                <textarea name="comment" rows="6" placeholder="Share your comment" required>

                </textarea>
                <button type="submit" class="send-btn">
                    <i class="fas fa-paper-plane"></i> Send
                </button>
            </form>
        </div>
                <nav class="login-buttons">
            <a href="login.html" class="btn-login"><i class="fas fa-user-graduate"></i> Login</a>
            <a href="CreateAccount.html" class="btn-CreateAccount"><i class="fas fa-user-plus"></i> Create Account</a>
        </nav>

    </body>
    </html>