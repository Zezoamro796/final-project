    const passIcons = document.querySelectorAll('.toggle-password');
    passIcons.forEach(btn => {
        btn.onclick = function() {
            const parent = this.closest('.field-wrapper');
            const input = parent.querySelector('input');
            if (input.type === 'password') {
                input.type = 'text';
                this.classList.replace('fa-eye-slash', 'fa-eye');
            } else {
                input.type = 'password';
                this.classList.replace('fa-eye', 'fa-eye-slash');
            }
        };
    });

    const form = document.querySelector('.CreateAccount-form');
    const btn = document.getElementById('submit-btn');

    btn.onclick = function(e) {
        let inputs = form.querySelectorAll('input[required], select[required]');
        let emptyFields = 0;

        inputs.forEach(el => {
            if (!el.value.trim()) {
                emptyFields++;
                el.style.borderColor = "#d82020";
            } else {
                el.style.borderColor = "rgba(255, 255, 255, 0.1)";
            }
        });

        if (emptyFields > 0) {
            e.preventDefault();
            btn.classList.add('shake-it');
            setTimeout(() => {
                btn.classList.remove('shake-it');
            }, 500);
        }
    };
