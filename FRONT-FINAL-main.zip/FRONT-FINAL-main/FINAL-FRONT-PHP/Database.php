<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@400;700;900&family=Montserrat:wght@400;800&family=Orbitron:wght@400;900&family=Kanit:wght@400;700&family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="Assets/blog_final.css">
</head>
<body>

<div class="container">
   <div class="blog-container">
            <div class="blog-card">
            <img src="Assets/images/database.gif" alt="data" class="floating-img">
            <div class="card-text">
               <h2 class="blog-title">Database Security: SQL Injection Prevention</h2>
            <h2>How to Write Secure Queries Using Prepared Statements</h2>
                <p>SQL Injection (SQLi) is one of the oldest and most dangerous web vulnerabilities. It occurs when untrusted user input is directly concatenated into a database query, allowing an attacker to manipulate the query structure. The most effective defense against this is the use of <strong>Prepared Statements</strong>.</p>
                <h3>The Problem: Query Concatenation</h3>
                <p>When you build queries like this, you are vulnerable:</p>
                <div class="code-container">
                    <pre><code>// DANGEROUS: Concatenation
$username = $_POST['username'];
$query = "SELECT * FROM users WHERE username = '" . $username . "'";</code></pre>
                </div>
                <p>An attacker can input <code>' OR '1'='1</code>, changing your query to return every user in the database. The database cannot distinguish between your code and the attacker's data.</p>

                <h3>The Solution: Prepared Statements</h3>
                <p>Prepared Statements (or Parameterized Queries) separate the <strong>SQL code</strong> from the <strong>data</strong>. When you use them, the database compiles the query first with placeholders (?), and then inserts the data safely.</p>
                
                <div class="code-container">
                    <pre><code>// SECURE: Prepared Statement
$stmt = $pdo->prepare('SELECT * FROM users WHERE username = ?');
$stmt->execute([$username]);
$user = $stmt->fetch();</code></pre>
                </div>

                <h3>Why This Is Secure</h3>
                <ul>
                    <li><strong>Separation of Concerns:</strong> The database engine receives the structure of the query before the data is added.</li>
                    <li><strong>No Code Execution:</strong> Because the input is treated strictly as data, the database will never execute it as a command, regardless of what characters the attacker uses (like quotes or semicolons).</li>
                </ul>
                <h3>Best Practices for Database Security</h3>
                <ol>
                    <li><strong>Always Use PDO or MySQLi:</strong> Never use the deprecated <code>mysql_query</code> functions.</li>
                    <li><strong>Bind All Inputs:</strong> Every user-provided variable must be passed through a parameter binding method.</li>
                    <li><strong>Principle of Least Privilege:</strong> Ensure the database user connected to your web application only has the permissions it absolutely needs (e.g., no <code>DROP TABLE</code> access if not required).</li>
                </ol>
                <div class="field-mission">
                    <h3> Field Mission (CyberWeave Challenge)</h3>
                    <p>In our "Secure Lab," try to log in using the same <code>' OR '1'='1</code> payload. Notice how the application now treats this as a literal username rather than a query? You have successfully defended against SQL Injection.</p>
                </div>
            </div>
         </div> 
         <div class="comments-section">
            <h3 class="comments-title"><i class="fas fa-comments"></i> Leave a Comment</h3>
            <form action="#" method="POST" class="comment-form">
                <div class="input-group">
                    <input type="text" name="username" placeholder="Your Username" required>
                    <input type="email" name="email" placeholder="Your Email" required>
                </div>
                <textarea name="comment" rows="6" placeholder="Share your comment" required>

                </textarea>
                <button type="submit" class="send-btn">
                    <i class="fas fa-paper-plane"></i> Send
                </button>
            </form>
        </div>
                <nav class="login-buttons">
            <a href="login.html" class="btn-login"><i class="fas fa-user-graduate"></i> Login</a>
            <a href="CreateAccount.html" class="btn-CreateAccount"><i class="fas fa-user-plus"></i> Create Account</a>
        </nav>

    </body>
    </html>