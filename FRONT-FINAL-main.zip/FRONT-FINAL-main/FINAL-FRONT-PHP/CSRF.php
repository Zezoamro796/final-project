<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@400;700;900&family=Montserrat:wght@400;800&family=Orbitron:wght@400;900&family=Kanit:wght@400;700&family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="Assets/blog_final.css">
</head>
<body>

<div class="container">
   <div class="blog-container">
            <div class="blog-card">
            <img src="Assets/images/CSRF.gif" alt="data" class="floating-img">
            <div class="card-text">
               <h2 class="blog-title">CSRF</h2>

            <p>CSRF exploits the browser’s automatic behavior of sending cookies with every request to a specific domain. Because the browser automatically attaches your session cookies, the server cannot distinguish between a legitimate request you initiated and a forged one sent by an attacker.</p>
                <h3>The Scenario: A "Ghost" Transaction</h3>
                <ul>
                    <li>You are logged into <code>mybank.com</code>.</li>
                    <li>An attacker sends you a link (perhaps an image or a fake button in an email).</li>
                    <li>When you open that link, a hidden script runs on the attacker's page, sending a request to <code>mybank.com/transfer?amount=1000&to=hacker</code>.</li>
                    <li>Because you are logged in, your browser automatically includes your valid session cookies with that request.</li>
                    <li>The bank receives the request, verifies your cookies, and processes the transfer, thinking you authorized it.</li>
                </ul>
           <h3>Why Is It So Dangerous?</h3>
                <ul>
                    <li><strong>Browser Trust:</strong> Convenience features (auto-attaching cookies) are turned into security liabilities.</li>
                    <li><strong>Lack of Verification:</strong> Applications often incorrectly assume that a valid session cookie equals user intent.</li>
                </ul>

               <h3>How to Defend Your Website</h3>
                <ol>
                    <li><strong>Anti-CSRF Tokens:</strong> The server generates a unique, unpredictable "token" for the session. This token must be included in every state-changing request. If the token is missing or incorrect, the request is rejected.</li>
                    <li><strong>SameSite Cookie Attribute:</strong> Set your session cookies to 
                        <code>
                            SameSite=Strict
                        </code> 
                        or 
                        <code>
                            Lax
                        </code>
                         This prevents the browser from sending cookies with cross-site requests.</li>
                    <li>
                        <strong>
                            Re-Authentication:
                        </strong>
                         For highly sensitive actions (e.g., password changes), always require the user to re-enter their password or provide an OTP
                        </li>
                </ol>

                    <h3>CSRF vs. XSS: Know the Difference</h3>
                <p><strong>XSS:</strong> The attacker steals your data (like your session tokens or personal information).</p>
                <p><strong>CSRF:</strong> The attacker uses your identity to perform actions (like changing your profile, making payments, or deleting content).</p>

                <div class="field-mission">
                    <h3></i> Field Mission (CyberWeave Challenge)</h3>
                    <p>In our Vulnerable Lab, try to perform an action on your account using a simple HTML file hosted on a different local port. If the action succeeds without a token, your site is vulnerable to CSRF.</p>
                </div>

            </div>
         </div> 
         <div class="comments-section">
            <h3 class="comments-title"><i class="fas fa-comments"></i> Leave a Comment</h3>
            <form action="#" method="POST" class="comment-form">
                <div class="input-group">
                    <input type="text" name="username" placeholder="Your Username" required>
                    <input type="email" name="email" placeholder="Your Email" required>
                </div>
                <textarea name="comment" rows="6" placeholder="Share your comment" required>

                </textarea>
                <button type="submit" class="send-btn">
                    <i class="fas fa-paper-plane"></i> Send
                </button>
            </form>
        </div>

                <nav class="login-buttons">
            <a href="login.html" class="btn-login"><i class="fas fa-user-graduate"></i> Login</a>
            <a href="CreateAccount.html" class="btn-CreateAccount"><i class="fas fa-user-plus"></i> Create Account</a>
        </nav>

    </body>
    </html>