<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@400;700;900&family=Montserrat:wght@400;800&family=Orbitron:wght@400;900&family=Kanit:wght@400;700&family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="Assets/blog_final.css">
</head>
<body>

<div class="container">
   <div class="blog-container">
            <div class="blog-card">
            <img src="Assets/images/Management.gif" alt="data" class="floating-img">
            <div class="card-text">
               <h2 class="blog-title">Session Management</h2>
            <h2>How to Fortify Your Cookies Against Theft</h2>
               <p>Authentication verifies who you are, but 
                <strong>
                    Session Management
                </strong>
                 defines how long you stay authenticated. 
                 If your session identifiers are weak or improperly handled,
                  an attacker can hijack your identity without ever knowing your password.</p>
                <h3>The Anatomy of a Session</h3>
                <p>When you log in, the server issues a "Session ID,
                    " usually stored in a cookie. This ID is the key to your digital identity.
                     If an attacker steals this key, they possess your active session, effectively 
                     "becoming" you until the session expires.</p>

                <h3>Core Defense Strategies</h3>
                <p>To make your session cookies "bulletproof," 
                    you must implement these security flags:</p>
                <ul>
                    <li><strong>HttpOnly:</strong> Prevents JavaScript from accessing the cookie. This is your primary defense against XSS-based cookie theft.</li>
                    <li><strong>Secure:</strong> Ensures the cookie is only sent over encrypted (HTTPS) connections, preventing interception via Man-in-the-Middle (MitM) attacks.</li>
                    <li><strong>SameSite (Strict/Lax):</strong> Prevents the browser from sending cookies with cross-site requests, protecting against CSRF.</li>
                </ul>
                <h3>Session Lifecycle Best Practices</h3>
                <ol>
                    <li><strong>Regeneration:</strong> Always regenerate the Session ID immediately after a successful login to prevent "Session Fixation" attacks.</li>
                    <li><strong>Timeout Policies:</strong> Implement both absolute and idle timeouts. A session that never expires is a session waiting to be abused.</li>
                    <li><strong>Encryption:</strong> While flags protect the transport, encrypting the session data on the server side adds an extra layer of protection.</li>
                </ol>

                <div class="code-container">
                    <strong>// SECURE: Setting Session Cookies in PHP</strong>
                    <pre><code>// Set flags before session starts
session_set_cookie_params([
    'lifetime' => 3600,
    'path' => '/',
    'domain' => 'cyberweave.com',
    'secure' => true,     // Only HTTPS
    'httponly' => true,   // No JS access
    'samesite' => 'Strict'
]);
session_start();
session_regenerate_id(true); // Prevent fixation</code></pre>
                </div>

                <div class="field-mission">
                    <h3><i class="fas fa-terminal"></i> Field Mission (CyberWeave Challenge)</h3>
                    <p>In the "Cookie Lab," try to read your session cookie using the browser console (<code>document.cookie</code>). If you have correctly implemented the <code>HttpOnly</code> flag, the console will return an empty string, confirming your session is protected from script-based theft.</p>
                </div>

            </div>
         </div> 
         <div class="comments-section">
            <h3 class="comments-title"><i class="fas fa-comments"></i> Leave a Comment</h3>
            <form action="#" method="POST" class="comment-form">
                <div class="input-group">
                    <input type="text" name="username" placeholder="Your Username" required>
                    <input type="email" name="email" placeholder="Your Email" required>
                </div>
                <textarea name="comment" rows="6" placeholder="Share your comment" required>

                </textarea>
                <button type="submit" class="send-btn">
                    <i class="fas fa-paper-plane"></i> Send
                </button>
            </form>
        </div>

                <nav class="login-buttons">
            <a href="login.html" class="btn-login"><i class="fas fa-user-graduate"></i> Login</a>
            <a href="CreateAccount.html" class="btn-CreateAccount"><i class="fas fa-user-plus"></i> Create Account</a>
        </nav>

    </body>
    </html>