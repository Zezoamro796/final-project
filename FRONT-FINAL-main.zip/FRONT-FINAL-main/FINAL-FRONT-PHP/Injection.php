<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@400;700;900&family=Montserrat:wght@400;800&family=Orbitron:wght@400;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="Assets/blog_final.css">
</head>
<body>
<main class="container">
    <div class="blog-container">
            <div class="blog-card">
            <img src="Assets/images/Injection.gif" alt="IDOR" class="floating-img">
            <div class="card-text">
                <h2 class="blog-title">Command Injection</h2>

                <h2>Turning Your Server Into a Puppet</h2>
                <p>While SQL Injection targets your database, Command Injection targets the very heart of the system—the operating system (OS) itself. It is widely considered one of the most critical vulnerabilities because, if successful, it grants the attacker direct control over the server hosting your website.</p>                
                <h3>The Mechanism of IDOR</h3>
                <h3>What is Command Injection?</h3>
                <p>Command Injection occurs when an application passes unsafe user input (forms, cookies, HTTP headers) to a system shell or terminal. By injecting their own commands, an attacker can force the server to execute malicious actions—such as deleting files, installing malware, or opening a backdoor—with the privileges of the web application.</p>
                <h3>How It Works: The "Ping" Trap</h3>
                <p>Imagine your website offers a diagnostic tool for users to "ping" an IP address. Behind the scenes, the code might look like this:</p>
                <div class="code-container">
                    <code>system("ping -c 3 " + user_input);</code>
                </div>
                <p>If a user enters a valid IP (e.g., <code>8.8.8.8</code>), the server runs <code>ping -c 3 8.8.8.8</code>. However, a malicious user could input:</p>
                <div class="code-container">
                    <code>8.8.8.8 ; rm -rf /</code>
                </div>
                <p>Because of the <code>;</code> (semicolon), the server executes the ping first, and then immediately executes <code>rm -rf /</code> (the command to delete everything). Suddenly, your server is compromised.</p>
                <h3>Why Is It So Dangerous?</h3>

              <h3>How to Defend Your Server</h3>
                <p>In the CyberWeave security philosophy, we prioritize defense-in-depth:</p>
                <ol>
                    <li><strong>Avoid System Calls:</strong> Never pass user input to <code>system()</code>, <code>exec()</code>, or <code>shell_exec()</code>. Use native language functions instead.</li>
                    <li><strong>Strict Input Validation:</strong> Use a whitelist approach; ensure the input contains only allowed characters (e.g., only numbers and dots for an IP).</li>
                    <li><strong>Use Escaping Libraries:</strong> Use functions like <code>escapeshellarg()</code>, which treat user input as a single, harmless argument.</li>
                    <li><strong>Least Privilege:</strong> Configure your web server (Apache/Nginx) to run with the lowest possible system permissions.</li>
                </ol>

                <div class="field-mission">
                    <h3><i class="fas fa-terminal"></i> Field Mission (CyberWeave Challenge)</h3>
                    <p>In our Vulnerable Lab, navigate to the "Diagnostic Tool" section. Try to inject a command using <code>;</code> or <code>&&</code> to list the system files (e.g., <code>8.8.8.8 && ls -la</code>). If the server displays the file directory, you have successfully confirmed a Command Injection vulnerability.</p>
                </div>
            </div>
            </div>


         <div class="comments-section">
            <h3 class="comments-title"><i class="fas fa-comments"></i> Leave a Comment</h3>
            <form action="#" method="POST" class="comment-form">
                <div class="input-group">
                    <input type="text" name="username" placeholder="Your Username" required>
                    <input type="email" name="email" placeholder="Your Email" required>
                </div>
                <textarea name="comment" rows="6" placeholder="Share your comment" required>

                </textarea>
                <button type="submit" class="send-btn">
                    <i class="fas fa-paper-plane"></i> Send
                </button>
            </form>
        </div>

                <nav class="login-buttons">
            <a href="login.html" class="btn-login"><i class="fas fa-user-graduate"></i> Login</a>
            <a href="CreateAccount.html" class="btn-CreateAccount"><i class="fas fa-user-plus"></i> Create Account</a>
        </nav>

</body>
</html>