<?php
// ============================================================
//  CyberWeave  |  logout.php
// ============================================================
require_once 'config.php';
session_safe_start();
session_unset();
session_destroy();
header('Location: login.php');
exit;
