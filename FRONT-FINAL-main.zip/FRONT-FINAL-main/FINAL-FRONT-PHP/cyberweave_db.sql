-- ============================================================
--  CyberWeave  |  Database Schema + Seed Data
--  Run this in phpMyAdmin after creating the DB "cyberweave_db"
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- --------------------------------------------------------
-- Table: users
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id`            INT UNSIGNED    NOT NULL AUTO_INCREMENT,
  `full_name`     VARCHAR(120)    NOT NULL,
  `email`         VARCHAR(180)    NOT NULL UNIQUE,
  `password_hash` VARCHAR(255)    NOT NULL,
  `phone`         VARCHAR(20)     DEFAULT NULL,
  `age`           TINYINT UNSIGNED DEFAULT NULL,
  `gender`        ENUM('male','female','other') DEFAULT NULL,
  `city`          VARCHAR(80)     DEFAULT NULL,
  `role`          ENUM('student','admin') NOT NULL DEFAULT 'student',
  `created_at`    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_login`    DATETIME        DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: security_events  (events shown in the dashboard timeline)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `security_events` (
  `id`           INT UNSIGNED   NOT NULL AUTO_INCREMENT,
  `event_type`   VARCHAR(80)    NOT NULL,
  `severity`     ENUM('low','medium','high','critical') NOT NULL DEFAULT 'medium',
  `environment`  ENUM('vulnerable','secure','both')     NOT NULL DEFAULT 'both',
  `description`  TEXT           DEFAULT NULL,
  `scenario_code` VARCHAR(30)   DEFAULT NULL,
  `icon`         VARCHAR(40)    DEFAULT 'fa-shield',
  `created_at`   DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: attack_logs  (used for the Chart.js timeline chart)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `attack_logs` (
  `id`              INT UNSIGNED   NOT NULL AUTO_INCREMENT,
  `environment`     ENUM('vulnerable','secure') NOT NULL,
  `requests_count`  SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  `interval_label`  VARCHAR(10)    NOT NULL,   -- e.g. "10:00"
  `recorded_at`     DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: page_visits  (tracks which blog pages users have read)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `page_visits` (
  `id`          INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  `user_id`     INT UNSIGNED  DEFAULT NULL,
  `page_name`   VARCHAR(100)  NOT NULL,
  `ip_address`  VARCHAR(45)   DEFAULT NULL,
  `visited_at`  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
--  SEED DATA  — Realistic initial data for a live-looking dashboard
-- ============================================================

-- Demo admin user  (password: Admin@123)
INSERT IGNORE INTO `users` (`full_name`,`email`,`password_hash`,`phone`,`age`,`gender`,`city`,`role`,`created_at`,`last_login`) VALUES
('Admin CyberWeave','admin@cyberweave.com','$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','01000000000',30,'male','Cairo','admin', NOW(), NOW());

-- Security Events (timeline feed)
INSERT INTO `security_events` (`event_type`,`severity`,`environment`,`description`,`scenario_code`,`icon`,`created_at`) VALUES
('SQL Injection on login endpoint',         'high',   'both',       'Vulnerable lab leaked stack trace; secure lab sanitized input and blocked query.',            'SQLi-01',  'fa-database',      NOW() - INTERVAL 2  MINUTE),
('Session fixation attempt detected',       'medium', 'both',       'Secure lab rotated session ID and enforced HttpOnly and SameSite cookies.',                   'AUTH-03',  'fa-cookie-bite',   NOW() - INTERVAL 18 MINUTE),
('Reflected XSS in search',                 'low',    'both',       'Vulnerable lab echoed payload; secure lab encoded output and enforced CSP.',                   'XSS-02',   'fa-code',          NOW() - INTERVAL 43 MINUTE),
('CSRF token missing on profile update',    'high',   'vulnerable', 'POST request accepted without CSRF token in the vulnerable environment.',                      'CSRF-01',  'fa-shield-halved', NOW() - INTERVAL 1  HOUR),
('IDOR on user profile endpoint',           'critical','vulnerable','User accessed another profile by iterating id parameter (id=1 returned admin data).',          'IDOR-01',  'fa-user-secret',   NOW() - INTERVAL 2  HOUR),
('Command Injection via ping tool',         'critical','both',       'Input "8.8.8.8; ls -la" executed on the OS in vulnerable lab.',                               'CMD-01',   'fa-terminal',      NOW() - INTERVAL 3  HOUR),
('Broken Authentication: weak password',   'medium', 'vulnerable', 'Account created with password "1234" — no strength policy enforced.',                          'AUTH-01',  'fa-lock-open',     NOW() - INTERVAL 5  HOUR),
('Sensitive data in HTML comments',         'low',    'vulnerable', 'DB password found in page source <!-- db_pass=root -->.',                                      'DATA-01',  'fa-eye',           NOW() - INTERVAL 6  HOUR),
('API Key hardcoded in JS file',            'high',   'vulnerable', 'API key "sk-abc123..." found committed to public repo history.',                              'API-01',   'fa-key',           NOW() - INTERVAL 8  HOUR),
('XSS Stored in comment form',              'high',   'vulnerable', 'Malicious script stored in comments table, executes on every page load.',                     'XSS-03',   'fa-comment-dots',  NOW() - INTERVAL 10 HOUR);

-- Attack chart data — last 8 ten-minute intervals
INSERT INTO `attack_logs` (`environment`,`requests_count`,`interval_label`,`recorded_at`) VALUES
('vulnerable', 62, '10:00', NOW() - INTERVAL 80 MINUTE),
('secure',     78, '10:00', NOW() - INTERVAL 80 MINUTE),
('vulnerable', 49, '10:10', NOW() - INTERVAL 70 MINUTE),
('secure',     82, '10:10', NOW() - INTERVAL 70 MINUTE),
('vulnerable', 71, '10:20', NOW() - INTERVAL 60 MINUTE),
('secure',     75, '10:20', NOW() - INTERVAL 60 MINUTE),
('vulnerable', 55, '10:30', NOW() - INTERVAL 50 MINUTE),
('secure',     91, '10:30', NOW() - INTERVAL 50 MINUTE),
('vulnerable', 83, '10:40', NOW() - INTERVAL 40 MINUTE),
('secure',     70, '10:40', NOW() - INTERVAL 40 MINUTE),
('vulnerable', 44, '10:50', NOW() - INTERVAL 30 MINUTE),
('secure',     88, '10:50', NOW() - INTERVAL 30 MINUTE),
('vulnerable', 66, '11:00', NOW() - INTERVAL 20 MINUTE),
('secure',     77, '11:00', NOW() - INTERVAL 20 MINUTE),
('vulnerable', 58, '11:10', NOW() - INTERVAL 10 MINUTE),
('secure',     93, '11:10', NOW() - INTERVAL 10 MINUTE);
