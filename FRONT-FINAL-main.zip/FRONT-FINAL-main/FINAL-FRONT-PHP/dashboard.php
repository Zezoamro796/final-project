<?php
// ============================================================
//  CyberWeave  |  dashboard.php  — Server-Side Rendered Stats
// ============================================================
require_once 'config.php';
session_safe_start();

// --- Fetch initial stats server-side for instant page render ---
$init = ['attacks'=>128,'blocked'=>119,'blocked_pct'=>93,'vulns'=>6,'progress'=>64,'live_sessions'=>3];
$initial_events = [];

try {
    $pdo = db_connect();

    // Stats
    $attacks  = (int)$pdo->query("SELECT COUNT(*) FROM security_events WHERE created_at >= NOW() - INTERVAL 24 HOUR")->fetchColumn();
    if ($attacks === 0) $attacks = (int)$pdo->query("SELECT COUNT(*) FROM security_events")->fetchColumn();
    $blocked  = (int)$pdo->query("SELECT COUNT(*) FROM security_events WHERE environment IN ('secure','both')")->fetchColumn();
    $blocked_pct = $attacks > 0 ? round($blocked/$attacks*100) : 93;
    $vulns    = (int)$pdo->query("SELECT COUNT(*) FROM security_events WHERE severity IN ('high','critical') AND created_at >= NOW() - INTERVAL 24 HOUR")->fetchColumn();
    $total_u  = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='student'")->fetchColumn();
    $active_u = (int)$pdo->query("SELECT COUNT(DISTINCT user_id) FROM page_visits WHERE user_id IS NOT NULL")->fetchColumn();
    $progress = $total_u > 0 ? min(100, round($active_u/max(1,$total_u)*100)) : 64;
    if ($progress === 0) $progress = 64;
    $live_s   = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE last_login >= NOW() - INTERVAL 15 MINUTE")->fetchColumn();
    if ($live_s === 0) $live_s = 1;

    $init = compact('attacks','blocked','blocked_pct','vulns','progress') + ['live_sessions'=>$live_s];

    // Events
    $stmt = $pdo->query("
        SELECT event_type, severity, environment, description, scenario_code, icon,
               TIMESTAMPDIFF(MINUTE, created_at, NOW()) AS minutes_ago
        FROM security_events ORDER BY created_at DESC LIMIT 5
    ");
    foreach ($stmt->fetchAll() as $ev) {
        $m = (int)$ev['minutes_ago'];
        $ev['time_label'] = $m < 1 ? 'just now' : ($m < 60 ? "{$m} min ago" : (intdiv($m,60).' hr ago'));
        $initial_events[] = $ev;
    }

} catch (PDOException $ignored) {}

$sevClass = ['high'=>'event-severity-high','critical'=>'event-severity-high','medium'=>'event-severity-medium','low'=>'event-severity-low'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI-Powered Training Dashboard</title>
    <link rel="stylesheet" href="Assets/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>
    <main class="main">
        <header class="top-bar">
            <div class="top-title">
                <span>AI-Powered Training Dashboard</span>
                <h1>Secure Web Application Monitoring</h1>
            </div>
            <div class="top-actions">
                <a href="blog.php" class="pill-button pill-primary">
                    <i class="fa-solid fa-virus"></i> Launch Vulnerable Lab
                </a>
                <a href="blog-Secure.php" class="pill-button pill-secondary">
                    <i class="fa-solid fa-shield"></i> Launch Secure Lab
                </a>
                <button type="button" class="pill-button pill-ghost" onclick="refreshMetrics()">
                    <i class="fa-solid fa-rotate"></i> Refresh Metrics
                </button>
                <?php if (isset($_SESSION['user_name'])): ?>
                <span class="pill-button pill-ghost" style="cursor:default;">
                    <i class="fa-solid fa-user-graduate"></i>
                    <?= htmlspecialchars($_SESSION['user_name']) ?>
                </span>
                <a href="logout.php" class="pill-button pill-ghost"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
                <?php else: ?>
                <a href="login.php" class="pill-button pill-ghost"><i class="fa-solid fa-right-to-bracket"></i> Login</a>
                <?php endif; ?>
            </div>
        </header>

        <section class="hero-row">
            <article class="hero-card">
                <div class="hero-copy">
                    <h2><span>AI‑Powered</span> Cyber Attack Simulation</h2>
                    <p>
                        Compare requests, responses, and security controls between
                        vulnerable and hardened implementations in real time, with
                        AI-assisted threat detection highlighting dangerous behavior.
                    </p>
                    <div class="hero-tags">
                        <span class="tag-chip">Live Traffic Mirroring</span>
                        <span class="tag-chip">OWASP Top 10 Focus</span>
                        <span class="tag-chip">Attack Replay &amp; Analysis</span>
                    </div>
                    <div class="hero-buttons">
                        <button type="button" class="pill-button pill-ghost" onclick="scrollToThreats()">
                            <i class="fa-solid fa-chart-line"></i> View Threat Timeline
                        </button>
                    </div>
                </div>

                <div class="hero-visual">
                    <div class="hero-orbit"></div>
                    <div class="hero-overlay-card">
                        <div class="hero-overlay-row">
                            <div>
                                <span>Live Sessions</span>
                                <strong id="hero-live-sessions"><?= str_pad($init['live_sessions'],2,'0',STR_PAD_LEFT) ?></strong>
                            </div>
                            <div style="text-align:right;">
                                <span>Detection Coverage</span>
                                <strong><?= $init['blocked_pct'] ?>%</strong>
                            </div>
                        </div>
                        <div class="hero-badges">
                            <span class="hero-badge danger"><i class="fa-solid fa-bolt"></i> SQLi Burst</span>
                            <span class="hero-badge info"><i class="fa-solid fa-network-wired"></i> Anomaly Routing</span>
                            <span class="hero-badge"><i class="fa-solid fa-lock"></i> CSP Hardened</span>
                        </div>
                        <div class="hero-footer">
                            <span><i class="fa-solid fa-circle" style="color:#22c55e;font-size:0.5rem;"></i> AI engine online</span>
                            <span>Last sync: <span id="hero-last-sync"><?= date('H:i:s') ?></span></span>
                        </div>
                    </div>
                </div>
            </article>

            <aside class="stats-panel">
                <div class="stats-panel-header">
                    <div>
                        <strong>Training Snapshot</strong><br />
                        <span>Summary for the last 24 hours</span>
                    </div>
                    <span class="pill-tiny">Lab status: Stable</span>
                </div>
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-label">Executed Attacks</div>
                        <div class="stat-value">
                            <span id="stat-attacks"><?= $init['attacks'] ?></span>
                            <span class="stat-trend up"><i class="fa-solid fa-arrow-trend-up"></i> +18%</span>
                        </div>
                        <div class="stat-label">Scenarios completed in training labs.</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-label">Blocked Attempts</div>
                        <div class="stat-value">
                            <span id="stat-blocked"><?= $init['blocked'] ?></span>
                            <span class="stat-trend up"><i class="fa-solid fa-shield-check"></i> <?= $init['blocked_pct'] ?>% blocked</span>
                        </div>
                        <div class="stat-label">Secure lab prevention rate.</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-label">New Vulnerabilities</div>
                        <div class="stat-value">
                            <span id="stat-vulns"><?= str_pad($init['vulns'],2,'0',STR_PAD_LEFT) ?></span>
                            <span class="stat-trend down"><i class="fa-solid fa-arrow-trend-down"></i> −12%</span>
                        </div>
                        <div class="stat-label">Discovered in vulnerable implementation.</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-label">User Progress</div>
                        <div class="stat-value">
                            <span id="stat-progress"><?= $init['progress'] ?>%</span>
                            <span class="stat-trend up"><i class="fa-solid fa-user-graduate"></i> +4% this week</span>
                        </div>
                        <div class="stat-label">Average completion across all trainees.</div>
                    </div>
                </div>
            </aside>
        </section>

        <section class="lower-grid" id="threat-timeline">
            <article class="card">
                <header class="card-header">
                    <div>
                        <strong>Lab Environments</strong><br />
                        <span>Compare vulnerable vs. secure implementations</span>
                    </div>
                    <span class="pill-tiny">Side‑by‑side mode</span>
                </header>
                <div class="labs-grid">
                    <div class="lab-card">
                        <div class="lab-chip vulnerable"><i class="fa-solid fa-bug"></i> Vulnerable Environment</div>
                        <div class="lab-meta">
                            <span>Attack surface: High</span>
                            <span>Risk score: 8.6 / 10</span>
                        </div>
                        <div class="lab-progress"><div class="lab-progress-bar vulnerable"></div></div>
                        <a href="blog.php" class="pill-button pill-primary lab-card-btn">Explore Vulnerable Flows</a>
                    </div>
                    <div class="lab-card">
                        <div class="lab-chip secure"><i class="fa-solid fa-shield-halved"></i> Secure Environment</div>
                        <div class="lab-meta">
                            <span>Attack surface: Reduced</span>
                            <span>Risk score: 2.1 / 10</span>
                        </div>
                        <div class="lab-progress"><div class="lab-progress-bar secure"></div></div>
                        <a href="blog-Secure.php" class="pill-button pill-secondary lab-card-btn">Review Mitigations</a>
                    </div>
                </div>

                <!-- Live events list — populated server-side & refreshed by JS -->
                <ul class="events-list events-list-spaced" id="events-list">
                    <?php foreach ($initial_events as $ev):
                        $sc = $sevClass[$ev['severity']] ?? 'event-severity-low';
                        $sevLabel = ucfirst($ev['severity']); ?>
                    <li class="event-item">
                        <div class="event-main">
                            <div class="event-badge"><i class="fa-solid <?= htmlspecialchars($ev['icon']) ?>"></i></div>
                            <div>
                                <div class="event-text-main"><?= htmlspecialchars($ev['event_type']) ?></div>
                                <div class="event-text-sub"><?= htmlspecialchars($ev['description']) ?></div>
                            </div>
                        </div>
                        <div class="event-meta">
                            <span class="<?= $sc ?>"><?= $sevLabel ?> • <?= htmlspecialchars($ev['time_label']) ?></span>
                            <span><?= $ev['scenario_code'] ? 'Scenario: '.htmlspecialchars($ev['scenario_code']) : '' ?></span>
                        </div>
                    </li>
                    <?php endforeach; ?>

                    <?php if (empty($initial_events)): ?>
                    <!-- Fallback static events (DB not yet connected) -->
                    <li class="event-item">
                        <div class="event-main">
                            <div class="event-badge"><i class="fa-solid fa-database"></i></div>
                            <div>
                                <div class="event-text-main">SQL Injection on login endpoint</div>
                                <div class="event-text-sub">Vulnerable lab leaked stack trace; secure lab sanitized input and blocked query.</div>
                            </div>
                        </div>
                        <div class="event-meta">
                            <span class="event-severity-high">High • 2 min ago</span>
                            <span>Scenario: SQLi‑01</span>
                        </div>
                    </li>
                    <li class="event-item">
                        <div class="event-main">
                            <div class="event-badge"><i class="fa-solid fa-cookie-bite"></i></div>
                            <div>
                                <div class="event-text-main">Session fixation attempt detected</div>
                                <div class="event-text-sub">Secure lab rotated session ID and enforced HttpOnly and SameSite cookies.</div>
                            </div>
                        </div>
                        <div class="event-meta">
                            <span class="event-severity-medium">Medium • 18 min ago</span>
                            <span>Scenario: AUTH‑03</span>
                        </div>
                    </li>
                    <li class="event-item">
                        <div class="event-main">
                            <div class="event-badge"><i class="fa-solid fa-code"></i></div>
                            <div>
                                <div class="event-text-main">Reflected XSS in search</div>
                                <div class="event-text-sub">Vulnerable lab echoed payload; secure lab encoded output and enforced CSP.</div>
                            </div>
                        </div>
                        <div class="event-meta">
                            <span class="event-severity-low">Low • 43 min ago</span>
                            <span>Scenario: XSS‑02</span>
                        </div>
                    </li>
                    <?php endif; ?>
                </ul>
            </article>

            <article class="card">
                <header class="card-header">
                    <div>
                        <strong>Attack Timeline</strong><br />
                        <span>Requests captured by the monitoring layer</span>
                    </div>
                    <span class="pill-tiny">Live data</span>
                </header>
                <div class="chart-wrapper">
                    <canvas id="threatChart"></canvas>
                </div>
            </article>
        </section>
    </main>
    <script src="Assets/Script.js"></script>
</body>

</html>