<?php
$success_message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars(trim($_POST['name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $message = htmlspecialchars(trim($_POST['message']));
    if (!empty($name) && !empty($email) && !empty($message)) {
        $success_message = "Thank you $name, your message has been received successfully.";
    }
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link rel="stylesheet" href="Assets/style-contact.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;800&family=Orbitron:wght@400;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body>
    <header>
        <h1>Contact Us</h1>
        <p>We are here to answer all your questions and inquiries</p>
    </header>

    <div class="container">
        <?php if ($success_message != ""): ?>
            <div class="alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>

        <div class="contact-wrapper">
            <div class="info-cards-container">
              
<div class="info-cards-container">
    <div class="info-card">
        <div class="icon-box"><i class="fas fa-map-marker-alt"></i></div>
        <div class="text-box">
            <span>Address</span>
            <p>Damitta Egypt</p>
        </div>
    </div>

    <div class="info-card">
        <div class="icon-box"><i class="fas fa-envelope"></i></div>
        <div class="text-box">
            <span>Email</span>
            <p>XXXXXX@gmail.com</p>
        </div>
    </div>

    <div class="info-card">
        <div class="icon-box"><i class="fas fa-phone-alt"></i></div>
        <div class="text-box">
            <span>Phone</span>
            <p>+201XXXXXXXX</p>
        </div>
    </div>
</div>
     </div>

            <div class="contact-form">
                <h2>Send us a Message</h2>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>
                    <div class="form-group">
                        <label for="name">Full Name:</label>
                        <input type="text" id="name" name="name" required placeholder="Enter your full name">
                    </div>
                    <div class="form-group">
                        <label for="email">Email Address:</label>
                        <input type="email" id="email" name="email" required placeholder="example@mail.com">
                    </div>
                    <div class="form-group">
                        <label for="message">Your Message</label>
                        <textarea id="message" name="message" rows="5" required placeholder="Write your inquiry here..."></textarea>
                    </div>
                    <button type="submit">Send Message</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>