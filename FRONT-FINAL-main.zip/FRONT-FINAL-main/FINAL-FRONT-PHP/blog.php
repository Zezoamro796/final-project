<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CyberWeave | Secure Learning</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@400;700;900&family=Montserrat:wght@400;800&family=Orbitron:wght@400;900&family=Kanit:wght@400;700&family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="Assets/blog.css">
</head>
<body>
    <header>
        <div class="logo-container">
            <img src="Assets/Images/logo.png" alt="CyberWeave Logo" class="logo-img">
            <a href="index.html" class="logo-text">
                <span class="cyber">Cyber</span><span class="weave">Weave</span>
            </a>
        </div>
        
        <nav class="login-buttons">
            <a href="login.php" class="btn-login"><i class="fas fa-user-graduate"></i> Login</a>
            <a href="CreateAccount.php" class="btn-CreateAccount"><i class="fas fa-user-plus"></i> Create Account</a>
        </nav>

    </header>
    
<section class="mastery-section">
    <div class="content-wrapper">
        <h1 class="main-title">Secure Your Inputs<br> Stop the Injection</h1>
        <!-- <p class="sub-title">Bridging the gap between vulnerable code and professional security standards</p> -->
    </div>
</section>                <!-- <a href="lessons.html" class="cta-button">Explore the Solution</a> -->
         <section class="search">
    <div class="search-container">
        <input type="text" placeholder="Search Blog " class="search-input">
        <button class="search-btn"><i class="fas fa-search"></i></button>
</div>
</section>
</div>
        </section>
<div class="container">
   <div class="blog-container">
        
        <div class="blog-card">
           <img src="Assets/images/NeverـTrust.gif" alt="Never Trust the User" class="floating-img">
            <div class="card-text">
                <h2 class="blog-title">Never Trust the User</h2>
                <p>In the world of software development, building a functional feature is only half the battle.
                     The other half—the half that separates mediocre code from professional-grade architecture—is Security........</p>
                <a href="trust.php" class="read-more">Read More <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>

        <div class="blog-card">
            <img src="Assets/images/SQL.gif" alt="SQL Injection" class="floating-img">
            <div class="card-text">
                <h2 class="blog-title">SQL Injection</h2>
                <p>SQL Injection: How a Single Character Can Destroy Your Database
In the cybersecurity world, some vulnerabilities require days of meticulous planning,
 while others are frighteningly simple—where a single character, like a single quote ('),
  can open the gates of hell. Today, we’re diving into the most notorious vulnerability in 
  web history: SQL Injection (SQLi).
What is SQL Injection (SQLi)?</p>
                <a href="sql.php" class="read-more">Read More <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>

                <div class="blog-card">
            <img src="Assets/images/ XSS.gif" alt="XSS" class="floating-img">
            <div class="card-text">
                <h2 class="blog-title">XSS</h2>
                <p>XSS (Cross-Site Scripting): When Your Browser Becomes a Spy
In the web ecosystem, we trust our browsers to be the ultimate gatekeepers of our data—managing 
the session cookies that keep us logged in and secure. However, what if a malicious actor could 
bypass that trust and force your browser to execute rogue commands? This is the dangerous reality of XSS.
What is an XSS Vulnerability?</p>
                <a href="XXS.php" class="read-more">Read More <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>

                <div class="blog-card">
            <img src="Assets/images/Broken.gif" alt="Broken Authentication" class="floating-img">
            <div class="card-text">
                <h2 class="blog-title">Broken Authentication</h2>
                <p>In cybersecurity, "Authentication" is the primary gatekeeper. 
                It is the mechanism that verifies you are who you claim to be. However, 
                what happens when that gatekeeper is incompetent or easily fooled?
                 This is the core of Broken Authentication.
                What is Broken Authentication?</p>
                <a href="Broken.php" class="read-more">Read More <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>

                <div class="blog-card">
            <img src="Assets/images/IDOR.gif" alt="IDOR" class="floating-img">
            <div class="card-text">
                <h2 class="blog-title">IDOR</h2>
                <p>Insecure Direct Object References (IDOR): The Hidden Vulnerability
In the landscape of web security, some vulnerabilities require complex exploits. Others, 
like IDOR (Insecure Direct Object Reference), are frighteningly simple: they exist because of a lack of proper access control. 
IDOR occurs when an application exposes a reference to an internal implementation object—such as a file, database record, 
or user profile—without verifying that the current user is authorized to access it.
The Mechanism of IDOR
An IDOR vulnerability typically surfaces when a web application uses a direct database key or identifier to fetch data.
For example.........</p>
                <a href="IDOR.php" class="read-more">Read More <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>

                <div class="blog-card">
            <img src="Assets/images/Injection.gif" alt="Command Injection" class="floating-img">
            <div class="card-text">
                <h2 class="blog-title">Command Injection</h2>
                <p>Command Injection: Turning Your Server Into a Puppet
While SQL Injection targets your database, Command Injection targets the very heart of the system—the operating system (OS) itself. 
It is widely considered one of the most critical vulnerabilities because, if successful, 
it grants the attacker direct control over the server hosting your website.
What is Command Injection?</p>
                <a href="Injection.php" class="read-more">Read More <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>

                <div class="blog-card">
            <img src="Assets/images/Data.gif" alt="Data Exposure" class="floating-img">
            <div class="card-text">
                <h2 class="blog-title">Sensitive Data Exposure via Comments</h2>
                <p>Data Exposure: Why You Should Never Leave Developer Comments in Your Code
In the journey of web development, we often write comments within our code as reminders for ourselves or our teammates.
 However, have you ever considered that this code, with all its "confessions," is delivered directly to the user's browser?
Yes, the comments you write in HTML or JavaScript files are visible to anyone who right-clicks and selects "View Page Source."
What is Sensitive Data Exposure via Comments?</p>
                <a href="data.php" class="read-more">Read More <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>

                <div class="blog-card">
            <img src="Assets/images/CSRF.gif" alt="CSRF" class="floating-img">
            <div class="card-text">
                <h2 class="blog-title">CSRF</h2>
                <p>SCSRF: How Attackers Execute Actions on Your Behalf
CSRF (Cross-Site Request Forgery) is one of the most deceptive vulnerabilities in web security.
 Unlike other attacks that focus on stealing data, CSRF focuses on misusing your authenticated session. 
It tricks your browser into performing actions on a website where you are currently logged in, 
without your knowledge or consent.How CSRF Works
CSRF exploits the browser’s automatic behavior of sending cookies with every request to a specific domain.
Because the browser automatically attaches your session cookies, 
the server cannot distinguish between a legitimate request you initiated and a forged one sent by an attacker.......</p>
                <a href="CSRF.php" class="read-more">Read More <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>

                <div class="blog-card">
            <img src="Assets/images/CTF.gif" alt="CTF" class="floating-img">
            <div class="card-text">
                <h2 class="blog-title">CTF</h2>
                <p>CTF Challenge: The "Vulnerable Lab" – Mission 01
Welcome, Agent. You are now entering the CyberWeave Vulnerable Lab. 
We have deliberately engineered a portal with a security flaw. Your mission is to find it, 
exploit it (ethically), and report the "flag" hidden in the database.The Objective
Your target is a simple User Profile Viewer.
<p>The URL: <span class="code">https://your-lab-site.com/profile.php?id=10</span></p>
The Goal: Can you access the profile of the administrator (ID: 1) without being logged in?</p>
                <a href="CTF.php" class="read-more">Read More <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>
    </main>
</body>