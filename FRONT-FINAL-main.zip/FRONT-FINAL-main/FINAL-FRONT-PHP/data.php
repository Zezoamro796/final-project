<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@400;700;900&family=Montserrat:wght@400;800&family=Orbitron:wght@400;900&family=Kanit:wght@400;700&family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="Assets/blog_final.css">
</head>
<body>

<div class="container">
   <div class="blog-container">
            <div class="blog-card">
            <img src="Assets/images/Data.gif" alt="data" class="floating-img">
            <div class="card-text">
               <h2 class="blog-title">Sensitive Data Exposure via Comments</h2>

            <h2>Why You Should Never Leave Developer Comments in Your Code</h2>
                <p>In the journey of web development, we often write comments within our code as reminders for ourselves or our teammates. However, have you ever considered that this code, with all its "confessions," is delivered directly to the user's browser? Yes, the comments you write in HTML or JavaScript files are visible to anyone who right-clicks and selects "View Page Source."</p>
                <h3>What is Sensitive Data Exposure via Comments?</h3>

            <p>It is a vulnerability where developers accidentally or lazily leave sensitive information within the source code of a web page. Since browsers render HTML/JS on the client side, every single line of code you write is technically "public."</p>

                <h3>Common "Confessions" Found in Code</h3>
                <p>Developers often unknowingly leak dangerous secrets in comments:</p>
                <ul>
                    <li><strong>Internal API Endpoints:</strong> Hidden URLs used for debugging that shouldn't be exposed.</li>
                    <li><strong>Hardcoded Credentials:</strong> Temporary database passwords or API keys left behind during testing.</li>
                    <li><strong>Logic Flaws:</strong> Comments like <code>// TODO: Fix this security check later</code> provide a roadmap for attackers.</li>
                    <li><strong>System Structure:</strong> Hints about file paths or server configurations.</li>
                </ul>

           <h3>Why This Is a High-Risk Vulnerability</h3>
                <p>Attackers use automated tools to crawl your website’s source code specifically looking for keywords like <code>TODO</code>, <code>FIXME</code>, or <code>API_KEY</code>. Once found, this information acts as a "skeleton key" to further exploit your infrastructure.</p>
                <h3>How to Prevent Data Exposure</h3>

                <ol>
                    <li><strong>Never Expose Secrets:</strong> Secrets like API keys and passwords should <strong>never</strong> exist in client-side files, not even in comments.</li>
                    <li><strong>Sanitize Production Code:</strong> Before deploying, ensure that your build process (e.g., Webpack or Gulp) automatically strips out all comments.</li>
                    <li><strong>Use Environment Variables:</strong> Store sensitive configurations on the server-side, not in your repository or source files.</li>
                    <li><strong>Review Before Commit:</strong> Always double-check your code for leftover debug messages or "TODO" notes before pushing to a live environment.</li>
                </ol>

                    <div class="field-mission">
                    <h3>Field Mission (CyberWeave Challenge)</h3>
                    <p>Navigate to our "Demo Page." Right-click and choose "View Page Source." Can you find the hidden API endpoint hidden in the comments? Once found, try to access it to see what information it leaks.</p>
                </div>

            </div>
         </div> 
         <div class="comments-section">
            <h3 class="comments-title"><i class="fas fa-comments"></i> Leave a Comment</h3>
            <form action="#" method="POST" class="comment-form">
                <div class="input-group">
                    <input type="text" name="username" placeholder="Your Username" required>
                    <input type="email" name="email" placeholder="Your Email" required>
                </div>
                <textarea name="comment" rows="6" placeholder="Share your comment" required>

                </textarea>
                <button type="submit" class="send-btn">
                    <i class="fas fa-paper-plane"></i> Send
                </button>
            </form>
        </div>

                <nav class="login-buttons">
            <a href="login.html" class="btn-login"><i class="fas fa-user-graduate"></i> Login</a>
            <a href="CreateAccount.html" class="btn-CreateAccount"><i class="fas fa-user-plus"></i> Create Account</a>
        </nav>

    </body>
    </html>