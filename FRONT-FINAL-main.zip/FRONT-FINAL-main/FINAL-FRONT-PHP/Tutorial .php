<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tutorial Playlist</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400&family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>
    <link rel="stylesheet" href="Assets/Tutorial.css">
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="Tutorial.js"></script>
</head>
<body>

<section class="courses-container">
    <h2 class="section-title">Watch Full Tutorial Playlist</h2>

    <div class="swiper mySwiper">
        <div class="swiper-wrapper">
            
            <div class="swiper-slide course-card highlight">
                <img src="Assets/Images/test.jpg" alt="CyberWeave Intro">
                <h3>What is CyberWeave?</h3>
                <p>Master web security by analyzing real-world vulnerabilities and building secure AI-powered applications</p>
                <a href="#" class="btn-enroll">Start Your Adventure <i class="fas fa-feather"></i></a>
            </div>

            <div class="swiper-slide course-card">
                <img src="Assets/Images/test.jpg" alt="Course Image">
                <h3>Second Course</h3>
                <p>Detailed description of the second course content and benefits</p>
                <a href="#" class="btn-enroll">Start Your Adventure <i class="fas fa-feather"></i></a>
            </div>

            <div class="swiper-slide course-card">
                <img src="Assets/Images/test.jpg" alt="Course Image">
                <h3>Third Course</h3>
                <p>Detailed description of the third course content and benefits</p>
                <a href="#" class="btn-enroll">Start Your Adventure <i class="fas fa-feather"></i></a>
            </div>

            <div class="swiper-slide course-card">
                <img src="Assets/Images/test.jpg" alt="Course Image">
                <h3>Fourth Course</h3>
                <p>Detailed description of the fourth course content and benefits</p>
                <span class="price">200$</span>
                <a href="#" class="btn-enroll">Start Your Adventure <i class="fas fa-feather"></i></a>
            </div>

            <div class="swiper-slide course-card">
                <img src="Assets/Images/test.jpg" alt="Course Image">
                <h3>Fifth Course</h3>
                <p>Detailed description of the fifth course content and benefits</p>
                <span class="price">200$</span>
                <a href="#" class="btn-enroll">Start Your Adventure <i class="fas fa-feather"></i></a>
            </div>

        </div>
    </div>
</section>


</body>
</html>