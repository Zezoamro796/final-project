<?php
// ============================================================
//  CyberWeave  |  login.php  — with real PHP authentication
// ============================================================
require_once 'config.php';

session_safe_start();

// Already logged in → redirect to dashboard
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error   = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email    = trim($_POST['email']    ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Please fill in all fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email address.';
    } else {
        try {
            $pdo  = db_connect();
            $stmt = $pdo->prepare("SELECT id, full_name, password_hash, role FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password_hash'])) {
                // Regenerate session to prevent fixation
                session_regenerate_id(true);
                $_SESSION['user_id']   = $user['id'];
                $_SESSION['user_name'] = $user['full_name'];
                $_SESSION['user_role'] = $user['role'];

                // Update last_login
                $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?")
                    ->execute([$user['id']]);

                // Log event
                $pdo->prepare("
                    INSERT INTO security_events (event_type,severity,environment,description,scenario_code,icon)
                    VALUES ('Successful Login','low','secure',?,  'AUTH-00','fa-user-check')
                ")->execute(["User '{$user['full_name']}' logged in successfully."]);

                header('Location: dashboard.php');
                exit;
            } else {
                $error = 'Invalid email or password.';
                // Log failed attempt
                try {
                    $pdo->prepare("
                        INSERT INTO security_events (event_type,severity,environment,description,scenario_code,icon)
                        VALUES ('Failed Login Attempt','medium','vulnerable',?,'AUTH-FAIL','fa-lock-open')
                    ")->execute(["Failed login attempt for email: {$email}"]);
                } catch (PDOException $ignored) {}
            }
        } catch (PDOException $e) {
            $error = 'Database error — please try again later.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - CyberWeave</title>
    <link rel="stylesheet" href="Assets/login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400&display=swap" rel="stylesheet">
    <style>
        .alert { padding:12px 16px; border-radius:8px; margin-bottom:14px; font-size:0.85rem; }
        .alert-error   { background:rgba(239,68,68,0.15);  color:#ef4444; border:1px solid rgba(239,68,68,0.3); }
        .alert-success { background:rgba(34,197,94,0.15);  color:#22c55e; border:1px solid rgba(34,197,94,0.3); }
    </style>
</head>
<body>
    <div class="SignIn-container">
        <form class="SignIn-form" method="POST" action="login.php">
            <div class="login-header">
                <h2>Welcome back!</h2>
                <p>We hope you have a wonderful learning experience <span>with us.</span></p>
            </div>

            <?php if (!empty($error)): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <?= htmlspecialchars($error) ?>
            </div>
            <?php endif; ?>

            <div class="input-group">
                <input type="email" name="email" placeholder="Email Address"
                       value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                <i class="fa-solid fa-envelope"></i>
            </div>

            <div class="input-group">
                <input type="password" name="password" placeholder="Password" id="login-pass" required>
                <i class="fa-solid fa-lock"></i>
            </div>

            <button type="submit" class="Login">Login</button>

            <p class="login-link" style="text-align:center;margin-top:14px;font-size:0.85rem;color:#999;">
                Don't have an account? <a href="CreateAccount.php" style="color:#e67e22;">Create one here</a>
            </p>
        </form>
    </div>
</body>
</html>
