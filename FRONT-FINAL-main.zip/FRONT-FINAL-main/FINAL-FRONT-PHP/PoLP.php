<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@400;700;900&family=Montserrat:wght@400;800&family=Orbitron:wght@400;900&family=Kanit:wght@400;700&family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="Assets/blog_final.css">
</head>
<body>

<div class="container">
   <div class="blog-container">
            <div class="blog-card">
            <img src="Assets/images/PoLP.gif" alt="PoLP" class="floating-img">
            <div class="card-text">
               <h2 class="blog-title">Principle of Least Privilege PoLP</h2>
           <h2>Protecting Your Server by Minimizing User Permissions</h2> 
                <p>In the security landscape, every permission you grant is a potential liability. 
                The Principle of Least Privilege (PoLP) dictates that every module, user, 
                and process must be able to access only the information and resources necessary for its legitimate purpose—nothing more.</p>
                <h3>What is Least Privilege?</h3>
                <p>It is the practice of restricting access rights for users and applications to the bare minimum. If an application only needs to read files from a specific folder, 
                it should not have 
                "Write" or "Execute" permissions anywhere else on the system.</p>
                <h3>Why This Stops Attackers</h3>
                <p>Imagine your web application is compromised via a vulnerability (like Command Injection). If that application is running as
                     <strong>
                        root
                    </strong>
                     the attacker gains full control of the entire server. However, if the application is running as a restricted
                     <code>
                        www-data
                    </code> 
                    user with limited access, the attacker is "trapped" within a sandbox and cannot modify system files or steal sensitive data from other users.</p>
                <h3>How to Implement PoLP</h3>
                <ol>
                    <li><strong>Dedicated Service Users:</strong> Never run web servers (Nginx/Apache) or database processes as the root user. Create a specific, low-privilege user for each service.</li>
                    <li><strong>File System Hardening:</strong> Use <code>chmod</code> and <code>chown</code> to strictly define who can read, write, or execute specific files.</li>
                    <li><strong>Database Granularity:</strong> Do not use the "root" database user for your web application. Create a dedicated database user that only has <code>SELECT</code>, <code>INSERT</code>, and <code>UPDATE</code> permissions on the tables it specifically needs.</li>
                    <li><strong>Regular Audits:</strong> Periodically review user permissions and remove any access that is no longer required.</li>
                </ol>

                <div class="code-container">
                    <strong>// SECURE: Database User Restriction (SQL)</strong>
                    <pre><code>-- Instead of granting all privileges to root:
GRANT SELECT, INSERT, UPDATE ON my_database.* TO 'app_user'@'localhost' 
IDENTIFIED BY 'secure_password';</code></pre>
                </div>

                <div class="field-mission">
                    <h3> Field Mission (CyberWeave Challenge)</h3>
                </div>

            </div>
         </div> 
         <div class="comments-section">
            <h3 class="comments-title"><i class="fas fa-comments"></i> Leave a Comment</h3>
            <form action="#" method="POST" class="comment-form">
                <div class="input-group">
                    <input type="text" name="username" placeholder="Your Username" required>
                    <input type="email" name="email" placeholder="Your Email" required>
                </div>
                <textarea name="comment" rows="6" placeholder="Share your comment" required>

                </textarea>
                <button type="submit" class="send-btn">
                    <i class="fas fa-paper-plane"></i> Send
                </button>
            </form>
        </div>

                <nav class="login-buttons">
            <a href="login.html" class="btn-login"><i class="fas fa-user-graduate"></i> Login</a>
            <a href="CreateAccount.html" class="btn-CreateAccount"><i class="fas fa-user-plus"></i> Create Account</a>
        </nav>

    </body>
    </html>