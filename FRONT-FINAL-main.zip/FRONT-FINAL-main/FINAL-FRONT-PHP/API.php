<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@400;700;900&family=Montserrat:wght@400;800&family=Orbitron:wght@400;900&family=Kanit:wght@400;700&family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="Assets/blog_final.css">
</head>
<body>

<div class="container">
   <div class="blog-container">
            <div class="blog-card">
            <img src="Assets/images/API.gif" alt="API Security" class="floating-img">
            <div class="card-text">
               <h2 class="blog-title">API Security</h2>

           <h2>How to Protect Your API Keys from Leakage</h2>
                
                <p>API keys are high-value targets. Developers often accidentally commit them to public code repositories, leaving their entire infrastructure wide open to anyone with an internet connection.</p>
                <h3>The Golden Rule: Never Hardcode</h3>
                <p>The most common mistake is embedding keys directly into source code. Even if you think your repository is private, a single configuration error can expose your keys to the world.</p>
                <h3>How to Secure Your Keys</h3>
                <ul>
                    <li><strong>Environment Variables:</strong> Store your keys in <code>.env</code> files that are <strong>never</strong> committed to Git. Use tools like <code>dotenv</code> to load them at runtime.</li>
                    <li><strong>Secret Management Services:</strong> For enterprise apps, use dedicated tools like AWS Secrets Manager, HashiCorp Vault, or Google Secret Manager.</li>
                    <li><strong>IP Whitelisting:</strong> If your API provider supports it, restrict key usage to specific IP addresses. If the key is stolen, it becomes useless outside your server.</li>
                    <li><strong>Rotate Your Keys:</strong> Regularly invalidate old keys and issue new ones. Treat them like passwords—they should not last forever.</li>
                </ul>
                <h3>Immediate Steps if a Key is Leaked</h3>
                <ol>
                    <li><strong>Revoke Immediately:</strong> Go to your provider's dashboard and delete or regenerate the leaked key.</li>
                    <li><strong>Audit Logs:</strong> Check your usage logs for any unauthorized activity that occurred while the key was exposed.</li>
                    <li><strong>Scan Repositories:</strong> Use tools like <code>git-secrets</code> or <code>TruffleHog</code> to ensure you haven't committed any other sensitive credentials by mistake.</li>
                </ol>

                <div class="field-mission">
                    <h3><i class="fas fa-terminal"></i> Field Mission (CyberWeave Challenge)</h3>
                    <p>In our "Credential Scavenger Hunt," we've hidden a fake API key in the public repository history. Can you find it using <code>git log</code>? Once found, think about how you would rewrite the history to permanently remove it.</p>
                </div>
            </div>
         </div> 
         <div class="comments-section">
            <h3 class="comments-title"><i class="fas fa-comments"></i> Leave a Comment</h3>
            <form action="#" method="POST" class="comment-form">
                <div class="input-group">
                    <input type="text" name="username" placeholder="Your Username" required>
                    <input type="email" name="email" placeholder="Your Email" required>
                </div>
                <textarea name="comment" rows="6" placeholder="Share your comment" required>

                </textarea>
                <button type="submit" class="send-btn">
                    <i class="fas fa-paper-plane"></i> Send
                </button>
            </form>
        </div>

                <nav class="login-buttons">
            <a href="login.html" class="btn-login"><i class="fas fa-user-graduate"></i> Login</a>
            <a href="CreateAccount.html" class="btn-CreateAccount"><i class="fas fa-user-plus"></i> Create Account</a>
        </nav>

    </body>
    </html>