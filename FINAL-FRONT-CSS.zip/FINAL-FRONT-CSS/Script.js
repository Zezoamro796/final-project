function randomSeries(base, variance) {
    return Array.from({ length: 8 }, function () {
        var delta = (Math.random() - 0.5) * variance;
        return Math.max(0, Math.round(base + delta));
    });
}

function refreshMetrics() {
    var attacks = 100 + Math.floor(Math.random() * 80);
    var blocked = Math.max(0, attacks - Math.floor(Math.random() * 18));
    var vulns = 3 + Math.floor(Math.random() * 6);
    var progress = 55 + Math.floor(Math.random() * 25);

    var elAttacks = document.getElementById("stat-attacks");
    var elBlocked = document.getElementById("stat-blocked");
    var elVulns = document.getElementById("stat-vulns");
    var elProgress = document.getElementById("stat-progress");

    if(elAttacks) elAttacks.textContent = attacks;
    if(elBlocked) elBlocked.textContent = blocked;
    if(elVulns) elVulns.textContent = ("0" + vulns).slice(-2);
    if(elProgress) elProgress.textContent = progress + "%";

    var sessions = 1 + Math.floor(Math.random() * 5);
    var elSessions = document.getElementById("hero-live-sessions");
    if(elSessions) elSessions.textContent = ("0" + sessions).slice(-2);

    var now = new Date();
    var formatted = now.getHours().toString().padStart(2, "0") + ":" +
        now.getMinutes().toString().padStart(2, "0") + ":" +
        now.getSeconds().toString().padStart(2, "0");
        
    var elLastSync = document.getElementById("hero-last-sync");
    if(elLastSync) elLastSync.textContent = formatted;

    if (window.threatChart) {
        var vulData = randomSeries(40, 26);
        var secData = randomSeries(75, 18);
        window.threatChart.data.datasets[0].data = vulData;
        window.threatChart.data.datasets[1].data = secData;
        window.threatChart.update();
    }
}

function scrollToThreats() {
    var el = document.getElementById("threat-timeline");
    if (el) {
        el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
}

document.addEventListener("DOMContentLoaded", function () {
    var canvas = document.getElementById("threatChart");
    if(!canvas) return;

    var ctx = canvas.getContext("2d");
    
    var gradientVulnerable = ctx.createLinearGradient(0, 0, 0, 400);
    gradientVulnerable.addColorStop(0, "rgba(239, 68, 68, 0.5)");
    gradientVulnerable.addColorStop(1, "rgba(239, 68, 68, 0)");

    var gradientSecure = ctx.createLinearGradient(0, 0, 0, 400);
    gradientSecure.addColorStop(0, "rgba(34, 197, 94, 0.5)");
    gradientSecure.addColorStop(1, "rgba(34, 197, 94, 0)");

    window.threatChart = new Chart(ctx, {
        type: "line",
        data: {
            labels:["10:00", "10:10", "10:20", "10:30", "10:40", "10:50", "11:00", "11:10"],
            datasets:[
                {
                    label: "Vulnerable Environment",
                    data: randomSeries(48, 28),
                    borderColor: "#ef4444",
                    backgroundColor: gradientVulnerable,
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 3,
                    pointBackgroundColor: "#ef4444"
                },
                {
                    label: "Secure Environment",
                    data: randomSeries(78, 18),
                    borderColor: "#22c55e",
                    backgroundColor: gradientSecure,
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 3,
                    pointBackgroundColor: "#22c55e"
                },
            ],
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: {
                        color: "#e5e7eb",
                        font: { family: "Inter", size: 12 },
                        usePointStyle: true,
                        padding: 20,
                    },
                },
                tooltip: {
                    mode: "index",
                    intersect: false,
                    backgroundColor: "rgba(0, 0, 0, 0.8)",
                    titleColor: "#e5e7eb",
                    bodyColor: "#e5e7eb",
                    borderColor: "rgba(255,255,255,0.1)",
                    borderWidth: 1,
                    padding: 12,
                },
            },
            interaction: { mode: "index", intersect: false },
            scales: {
                x: {
                    grid: { display: false },
                    ticks: { color: "#9ca3af", font: { family: "Inter", size: 11 } },
                },
                y: {
                    min: 0,
                    grid: { color: "rgba(255, 255, 255, 0.05)", drawBorder: false },
                    ticks: {
                        color: "#9ca3af",
                        font: { family: "Inter", size: 11 },
                        callback: function (value) { return value + " req/s"; },
                    },
                },
            },
        },
    });

    refreshMetrics();
    setInterval(refreshMetrics, 3000);
});