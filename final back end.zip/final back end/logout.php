<?php
session_start();
session_unset();
session_destroy();
header("Location: MAIN.php");
exit();
?>
