<?php
// Database configuration
$host = 'localhost';
$db   = 'cyberweave';
$user = 'root';
$pass = ''; // Default XAMPP password is empty
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
     $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
     // In a production environment, you should log error and show a generic message
     // throw new \PDOException($e->getMessage(), (int)$e->getCode());
     die("Connection failed: " . $e->getMessage());
}
?>
