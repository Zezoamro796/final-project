<?php
require_once 'config.php';

// Fetch comments for the current page
$page_name = basename($_SERVER['PHP_SELF']);
$stmt = $pdo->prepare("SELECT * FROM comments WHERE page_name = ? ORDER BY created_at DESC");
$stmt->execute([$page_name]);
$comments = $stmt->fetchAll();
?>

<div class="comments-display" style="margin-top: 30px; padding: 20px; background: rgba(255, 255, 255, 0.05); border-radius: 10px;">
    <h3 style="color: #fff; margin-bottom: 20px;"><i class="fas fa-list"></i> Recent Comments</h3>
    <?php if (empty($comments)): ?>
        <p style="color: #ccc;">No comments yet. Be the first to share your thoughts!</p>
    <?php else: ?>
        <?php foreach ($comments as $c): ?>
            <div class="comment-item" style="border-bottom: 1px solid rgba(255, 255, 255, 0.1); padding-bottom: 15px; margin-bottom: 15px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
                    <strong style="color: #3498db;"><?php echo htmlspecialchars($c['username']); ?></strong>
                    <small style="color: #888;"><?php echo $c['created_at']; ?></small>
                </div>
                <p style="color: #ddd; margin: 0;"><?php echo nl2br(htmlspecialchars($c['comment'])); ?></p>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
