<?php
require_once 'config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $page_name = $_POST['page_name'] ?? 'unknown';
    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';
    $comment = $_POST['comment'] ?? '';
    // Determine if we should use secure or vulnerable saving
    // For educational purposes, let's look at the filename or a hidden field
    $is_secure = (strpos($page_name, 'Secure') !== false || in_array($page_name, ['Database.php', 'Validation.php', 'BCrypt.php', 'Management.php', 'PoLP.php', 'API.php', 'SDLC.php', 'Security.php', 'Auditing.php']));

    if ($is_secure) {
        // SECURE: Prepared Statement
        $stmt = $pdo->prepare("INSERT INTO comments (page_name, username, email, comment) VALUES (?, ?, ?, ?)");
        $stmt->execute([$page_name, $username, $email, $comment]);
    } else {
        // VULNERABLE: Direct Concatenation (for educational demonstration if the user tries it)
        // Note: In a real "professional" app we wouldn't do this, but this is a security training app.
        // However, I will use the PDO exec for the vulnerable part to still make it "work" but show the flaw in logic if needed.
        // Actually, to be "professional" as requested, I'll stick to secure unless the user specifically asks for the vulnerable implementation logic to be active.
        // The user asked to make it live "professionally", so I'll use prepared statements for all for now, or use a toggle.
        
        $stmt = $pdo->prepare("INSERT INTO comments (page_name, username, email, comment) VALUES (?, ?, ?, ?)");
        $stmt->execute([$page_name, $username, $email, $comment]);
    }

    header("Location: " . $_SERVER['HTTP_REFERER']);
    exit();
}
?>
