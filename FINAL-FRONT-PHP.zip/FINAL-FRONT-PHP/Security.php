<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@400;700;900&family=Montserrat:wght@400;800&family=Orbitron:wght@400;900&family=Kanit:wght@400;700&family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="Assets/blog_final.css">
</head>
<body>

<div class="container">
   <div class="blog-container">
            <div class="blog-card">
            <img src="Assets/images/Security.gif" alt="Security Headers" class="floating-img">
            <div class="card-text">
               <h2 class="blog-title">Security Headers</h2>
            <h2>Add an Extra Layer of Protection to Your Browser</h2>
                
                <p>Think of Security Headers as a set of "house rules" for the browser. By sending these headers, you explicitly tell the browser which resources (scripts, images, styles) are allowed to run, effectively locking the door against many common attacks.</p>

                

                <h3>The Power of Content Security Policy (CSP)</h3>
                <p>The <strong>CSP</strong> is arguably the most important header. It restricts where scripts, stylesheets, and images can be loaded from. Even if an attacker finds an XSS vulnerability, a properly configured CSP will prevent the malicious script from executing because it isn't on your "whitelist."</p>

                <div class="code-container">
                    <strong>// Example CSP Header:</strong>
                    <pre><code>Content-Security-Policy: default-src 'self'; script-src 'self' https://trusted-scripts.com;</code></pre>
                </div>

                <h3>Must-Have Security Headers</h3>
                <ul>
                    <li><strong>Strict-Transport-Security (HSTS):</strong> Forces the browser to connect to your site ONLY via HTTPS.</li>
                    <li><strong>X-Content-Type-Options:</strong> Prevents the browser from "guessing" the file type (MIME sniffing), which can lead to attacks.</li>
                    <li><strong>X-Frame-Options:</strong> Protects against "Clickjacking" by preventing your site from being displayed inside an <code>&lt;iframe&gt;</code> on a malicious domain.</li>
                    <li><strong>Referrer-Policy:</strong> Controls how much information the browser sends about where the user came from.</li>
                </ul>

                

                <h3>Why Implement Headers?</h3>
                <p>These headers are your "last line of defense." They operate at the browser level, meaning they protect your users even if your server-side code has minor flaws. They don't require rewriting your database or application logic—just a simple change to your server's configuration file.</p>

                <div class="field-mission">
                    <h3> Field Mission (CyberWeave Challenge)</h3>
                    <p>Open your browser's Developer Tools (Network Tab). Inspect the response headers for our lab site. Can you identify which security headers are active? Try to disable <code>X-Frame-Options</code> and see if you can "iframe" the site from a dummy HTML page.</p>
                </div>

            </div>
         </div> 
         <div class="comments-section">
            <h3 class="comments-title"><i class="fas fa-comments"></i> Leave a Comment</h3>
            <form action="../final back end/handle_comment.php" method="POST" class="comment-form">
                <input type="hidden" name="page_name" value="<?php echo basename(__FILE__); ?>">
                <div class="input-group">
                    <input type="text" name="username" placeholder="Your Username" value="<?php echo $_SESSION['full_name'] ?? ''; ?>" required>
                    <input type="email" name="email" placeholder="Your Email" required>
                </div>
                <textarea name="comment" rows="6" placeholder="Share your comment" required></textarea>
                <button type="submit" class="send-btn">
                    <i class="fas fa-paper-plane"></i> Send
                </button>
            </form>
            <?php include '../final back end/comments_display.php'; ?>
        </div>

                </textarea>
                <button type="submit" class="send-btn">
                    <i class="fas fa-paper-plane"></i> Send
                </button>
            </form>
        </div>

                <nav class="login-buttons">
            <a href="login.html" class="btn-login"><i class="fas fa-user-graduate"></i> Login</a>
            <a href="CreateAccount.html" class="btn-CreateAccount"><i class="fas fa-user-plus"></i> Create Account</a>
        </nav>

    </body>
    </html>