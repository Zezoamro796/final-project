<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI-Powered Training Dashboard</title>
    <link rel="stylesheet" href="Assets/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>
    <main class="main">
        <header class="top-bar">
            <div class="top-title">
                <span>AI-Powered Training Dashboard</span>
                <h1>Secure Web Application Monitoring</h1>
            </div>
            <div class="top-actions">
                <a href="#" class="pill-button pill-primary">
                    <i class="fa-solid fa-virus"></i>
                    Launch Vulnerable Lab
                </a>
                <a href="#" class="pill-button pill-secondary">
                    <i class="fa-solid fa-shield"></i>
                    Launch Secure Lab
                </a>
                <button type="button" class="pill-button pill-ghost" onclick="refreshMetrics()">
                    <i class="fa-solid fa-rotate"></i>
                    Refresh Metrics
                </button>
            </div>
        </header>

        <section class="hero-row">
            <article class="hero-card">
                <div class="hero-copy">
                    <h2><span>AI‑Powered</span> Cyber Attack Simulation</h2>
                    <p>
                        Compare requests, responses, and security controls between
                        vulnerable and hardened implementations in real time, with
                        AI-assisted threat detection highlighting dangerous behavior.
                    </p>
                    <div class="hero-tags">
                        <span class="tag-chip">Live Traffic Mirroring</span>
                        <span class="tag-chip">OWASP Top 10 Focus</span>
                        <span class="tag-chip">Attack Replay &amp; Analysis</span>
                    </div>
                    <div class="hero-buttons">
                        <button type="button" class="pill-button pill-ghost" onclick="scrollToThreats()">
                            <i class="fa-solid fa-chart-line"></i>
                            View Threat Timeline
                        </button>
                    </div>
                </div>

                <div class="hero-visual">
                    <div class="hero-orbit"></div>
                    <div class="hero-overlay-card">
                        <div class="hero-overlay-row">
                            <div>
                                <span>Live Sessions</span>
                                <strong id="hero-live-sessions">03</strong>
                            </div>
                            <div style="text-align:right;">
                                <span>Detection Coverage</span>
                                <strong>92.4%</strong>
                            </div>
                        </div>
                        <div class="hero-badges">
                            <span class="hero-badge danger">
                                <i class="fa-solid fa-bolt"></i>
                                SQLi Burst
                            </span>
                            <span class="hero-badge info">
                                <i class="fa-solid fa-network-wired"></i>
                                Anomaly Routing
                            </span>
                            <span class="hero-badge">
                                <i class="fa-solid fa-lock"></i>
                                CSP Hardened
                            </span>
                        </div>
                        <div class="hero-footer">
                            <span><i class="fa-solid fa-circle"></i> AI engine online</span>
                            <span>Last sync: <span id="hero-last-sync">just now</span></span>
                        </div>
                    </div>
                </div>
            </article>

            <aside class="stats-panel">
                <div class="stats-panel-header">
                    <div>
                        <strong>Training Snapshot</strong><br />
                        <span>Summary for the last 24 hours</span>
                    </div>
                    <span class="pill-tiny">Lab status: Stable</span>
                </div>
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-label">Executed Attacks</div>
                        <div class="stat-value">
                            <span id="stat-attacks">128</span>
                            <span class="stat-trend up">
                                <i class="fa-solid fa-arrow-trend-up"></i>
                                +18%
                            </span>
                        </div>
                        <div class="stat-label">Scenarios completed in training labs.</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-label">Blocked Attempts</div>
                        <div class="stat-value">
                            <span id="stat-blocked">119</span>
                            <span class="stat-trend up">
                                <i class="fa-solid fa-shield-check"></i>
                                93% blocked
                            </span>
                        </div>
                        <div class="stat-label">Secure lab prevention rate.</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-label">New Vulnerabilities</div>
                        <div class="stat-value">
                            <span id="stat-vulns">06</span>
                            <span class="stat-trend down">
                                <i class="fa-solid fa-arrow-trend-down"></i>
                                −12%
                            </span>
                        </div>
                        <div class="stat-label">Discovered in vulnerable implementation.</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-label">User Progress</div>
                        <div class="stat-value">
                            <span id="stat-progress">64%</span>
                            <span class="stat-trend up">
                                <i class="fa-solid fa-user-graduate"></i>
                                +4% this week
                            </span>
                        </div>
                        <div class="stat-label">Average completion across all trainees.</div>
                    </div>
                </div>
            </aside>
        </section>

        <section class="lower-grid" id="threat-timeline">
            <article class="card">
                <header class="card-header">
                    <div>
                        <strong>Lab Environments</strong><br />
                        <span>Compare vulnerable vs. secure implementations</span>
                    </div>
                    <span class="pill-tiny">Side‑by‑side mode</span>
                </header>
                <div class="labs-grid">
                    <div class="lab-card">
                        <div class="lab-chip vulnerable">
                            <i class="fa-solid fa-bug"></i>
                            Vulnerable Environment
                        </div>
                        <div class="lab-meta">
                            <span>Attack surface: High</span>
                            <span>Risk score: 8.6 / 10</span>
                        </div>
                        <div class="lab-progress">
                            <div class="lab-progress-bar vulnerable"></div>
                        </div>
                        <button type="button" class="pill-button pill-primary lab-card-btn">
                            Explore Vulnerable Flows
                        </button>
                    </div>
                    <div class="lab-card">
                        <div class="lab-chip secure">
                            <i class="fa-solid fa-shield-halved"></i>
                            Secure Environment
                        </div>
                        <div class="lab-meta">
                            <span>Attack surface: Reduced</span>
                            <span>Risk score: 2.1 / 10</span>
                        </div>
                        <div class="lab-progress">
                            <div class="lab-progress-bar secure"></div>
                        </div>
                        <button type="button" class="pill-button pill-secondary lab-card-btn">
                            Review Mitigations
                        </button>
                    </div>
                </div>

                <ul class="events-list events-list-spaced">
                    <li class="event-item">
                        <div class="event-main">
                            <div class="event-badge">
                                <i class="fa-solid fa-database"></i>
                            </div>
                            <div>
                                <div class="event-text-main">SQL Injection on login endpoint</div>
                                <div class="event-text-sub">
                                    Vulnerable lab leaked stack trace; secure lab sanitized input and blocked query.
                                </div>
                            </div>
                        </div>
                        <div class="event-meta">
                            <span class="event-severity-high">High • 2 min ago</span>
                            <span>Scenario: SQLi‑01</span>
                        </div>
                    </li>
                    <li class="event-item">
                        <div class="event-main">
                            <div class="event-badge">
                                <i class="fa-solid fa-cookie-bite"></i>
                            </div>
                            <div>
                                <div class="event-text-main">Session fixation attempt detected</div>
                                <div class="event-text-sub">
                                    Secure lab rotated session ID and enforced HttpOnly and SameSite cookies.
                                </div>
                            </div>
                        </div>
                        <div class="event-meta">
                            <span class="event-severity-medium">Medium • 18 min ago</span>
                            <span>Scenario: AUTH‑03</span>
                        </div>
                    </li>
                    <li class="event-item">
                        <div class="event-main">
                            <div class="event-badge">
                                <i class="fa-solid fa-code"></i>
                            </div>
                            <div>
                                <div class="event-text-main">Reflected XSS in search</div>
                                <div class="event-text-sub">
                                    Vulnerable lab echoed payload; secure lab encoded output and enforced CSP.
                                </div>
                            </div>
                        </div>
                        <div class="event-meta">
                            <span class="event-severity-low">Low • 43 min ago</span>
                            <span>Scenario: XSS‑02</span>
                        </div>
                    </li>
                </ul>
            </article>
            <article class="card">
                <header class="card-header">
                    <div>
                        <strong>Attack Timeline</strong><br />
                        <span>Requests captured by the monitoring layer</span>
                    </div>
                    <span class="pill-tiny">Synthetic training data</span>
                </header>
                <div class="chart-wrapper">
                    <canvas id="threatChart"></canvas>
                </div>
            </article>
        </section>
    </main>
    <script src="Assets/Script.js"></script>
</body>

</html>