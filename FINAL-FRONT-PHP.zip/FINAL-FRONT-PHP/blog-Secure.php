<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CyberWeave | Secure Learning</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@400;700;900&family=Montserrat:wght@400;800&family=Orbitron:wght@400;900&family=Kanit:wght@400;700&family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="Assets/blog.css">
</head>
<body>
    <header>
        <div class="logo-container">
            <img src="Assets/Images/logo.png" alt="CyberWeave Logo" class="logo-img">
            <a href="MAIN.php" class="logo-text">
                <span class="cyber">Cyber</span><span class="weave">Weave</span>
            </a>
        </div>
        
        <nav class="login-buttons">
            <a href="login.php" class="btn-login"><i class="fas fa-user-graduate"></i> Login</a>
            <a href="CreateAccount.php" class="btn-CreateAccount"><i class="fas fa-user-plus"></i> Create Account</a>
        </nav>

    </header>
    
<section class="mastery-section">
    <div class="content-wrapper">
        <h1 class="main-title">Secure Your Inputs<br> Stop the Injection</h1>
        <!-- <p class="sub-title">Bridging the gap between vulnerable code and professional security standards</p> -->
    </div>
</section>                <!-- <a href="lessons.html" class="cta-button">Explore the Solution</a> -->
         <section class="search">
    <div class="search-container">
        <input type="text" placeholder="Search Blog " class="search-input">
        <button class="search-btn"><i class="fas fa-search"></i></button>
</div>
</section>
</div>
        </section>
<div class="container">
   <div class="blog-container">
        
        <div class="blog-card">
           <img src="Assets/images/Database.gif" alt="Database Security" class="floating-img">
            <div class="card-text">
                <h2 class="blog-title">Database Security: SQL Injection Prevention</h2>
                <p>How to Write Secure Queries Using Prepared Statements
                    SQL Injection (SQLi) is one of the oldest and most dangerous web vulnerabilities.
                     It occurs when untrusted user input is directly concatenated into a database query, allowing an attacker to manipulate the query structure. 
                     The most effective defense against this is the use of Prepared Statements........</p>
                <a href="Database.php" class="read-more">Read More <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>

        <div class="blog-card">
            <img src="Assets/images/Validation.gif" alt="Input Validation" class="floating-img">
            <div class="card-text">
                <h2 class="blog-title">Input Validation</h2>
                <h2>Never Trust Anyone: The Source-Based Sanitization Strategy</h2>
                <p>In the world of web security, the golden rule is simple yet profound: <strong>"Never Trust the User."</strong> Every piece of data sent from a client to your server is a potential weapon. Input Validation is your first line of defense against XSS (Cross-Site Scripting) and other injection attacks.</p>
                <h3>What is Input Validation?</h3>
                <a href="Validation.php" class="read-more">Read More <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>




                <div class="blog-card">
            <img src="Assets/images/password.gif" alt="XSS" class="floating-img">
            <div class="card-text">
                <h2 class="blog-title">Database Security: Password Hashing</h2>
                <h2>Why You Should Never Store Passwords in Plaintext</h2>
                <p>Storing user passwords as plaintext is a "security suicide." If your database is ever compromised, every user's account is instantly exposed. To protect users, we must use <strong>Hashing</strong>, but not just any hashing—we need algorithms designed to be slow and secure.</p>                
                <h3>Why Plaintext // Old Hashes Fail........</h3>
                <a href="BCrypt.php" class="read-more">Read More <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>

                <div class="blog-card">
            <img src="Assets/images/Management.gif" alt="Session Management" class="floating-img">
            <div class="card-text">
                <h2 class="blog-title">Session Management</h2>
                h2>How to Fortify Your Cookies Against Theft</h2>
                <p>Authentication verifies who you are, but 
                    <strong>Session Management</strong> 
                    defines how long you stay authenticated. 
                    If your session identifiers are weak or improperly handled, 
                    an attacker can hijack your identity without ever knowing your password.</p>
                <h3>The Anatomy of a Session</h3>
                <a href="Management.php" class="read-more">Read More <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>

                <div class="blog-card">
            <img src="Assets/images/PoLP.gif" alt="PoLP" class="floating-img">
            <div class="card-text">
                <h2 class="blog-title">Principle of Least Privilege PoLP</h2>
                <h2>Protecting Your Server by Minimizing User Permissions</h2>
                
                <p>In the security landscape, every permission you grant is a potential liability.
                     The Principle of Least Privilege (PoLP) dictates that every module, user, 
                     and process must be able to access only the information and resources necessary 
                     for its legitimate purpose—nothing more.</p>
                <h3>What is Least Privilege?</h3>
                <a href="PoLP.php" class="read-more">Read More <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>

                <div class="blog-card">
            <img src="Assets/images/API.gif" alt=" API Security" class="floating-img">
            <div class="card-text">
                <h2 class="blog-title">API Security</h2>
              <h2>How to Protect Your API Keys from Leakage</h2>
                <p>API keys are high-value targets. Developers often accidentally commit them to public code repositories, 
                    leaving their entire infrastructure wide open to anyone with an internet connection.</p>
                <a href="API.php" class="read-more">Read More <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>

                <div class="blog-card">
            <img src="Assets/images/SDLC.gif" alt=" Secure SDLC" class="floating-img">
            <div class="card-text">
                <h2 class="blog-title">Secure SDLC</h2>
                <h2>Integrating Security into Every Stage of Coding</h2>
                <p>Most developers treat security as a "bolt-on" feature—something to check right before releasing. However,
                    the Secure SDLC (Software Development Life Cycle) approach embeds security into the very DNA of your project, 
                    reducing costs and preventing vulnerabilities before they are even written</p>
                <h3>The Phases of Secure SDLC......</h3>
                <a href="SDLC.php" class="read-more">Read More <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>

                <div class="blog-card">
            <img src="Assets/images/Security.gif" alt="Security Headers" class="floating-img">
            <div class="card-text">
                <h2 class="blog-title">Security Headers</h2>
                 <h2>Add an Extra Layer of Protection to Your Browser</h2>
                <p>Think of Security Headers as a set of "house rules" for the browser. 
                    By sending these headers, you explicitly tell the browser which resources (scripts, images, styles) 
                    are allowed to run, effectively locking the door against many common attacks.</p>
                <h3>The Power of Content Security Policy (CSP)</h3>
                <a href="Security.php" class="read-more">Read More <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>

                <div class="blog-card">
            <img src="Assets/images/Auditing.gif" alt="Security Auditing" class="floating-img">
            <div class="card-text">
                <h2 class="blog-title">Security Auditing</h2>
                <h2>How to Audit Your Code Before Attackers Find the Flaws</h2>
                <p>Security is not a destination; it's a journey. Even with perfect initial code, 
                    new vulnerabilities (CVEs) are discovered every day.
                     Regular auditing ensures that your "walls" stay strong against modern threats.</p>
                <h3>The Two Pillars of Auditing</h3>
                <a href="Auditing.php" class="read-more">Read More <i class="fas fa-arrow-right"></i></a>
            </div>
        </div>
    </main>
</body>