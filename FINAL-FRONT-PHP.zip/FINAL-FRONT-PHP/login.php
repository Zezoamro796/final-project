<?php
require_once '../final back end/config.php';
session_start();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['user_email'] ?? '';
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['full_name'] = $user['full_name'];
        header("Location: MAIN.php");
        exit();
    } else {
        $error = "Invalid email or password!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - AI Secure Web</title>
    <link rel="stylesheet" href="Assets/login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
     <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400&display=swap" rel="stylesheet">
    </head>
<body>
    <div class="SignIn-container">
        <form class="SignIn-form" method="POST" action="login.php">
            <div class="login-header">
    <h2>Welcome back!</h2>
    <p>We hope you have a wonderful learning experience <span>with us.</span></p>
</div>

            <?php if ($error): ?>
                <p style="color: #ff4d4d; background: rgba(255, 77, 77, 0.1); padding: 10px; border-radius: 5px; margin-bottom: 15px; text-align: center;"><?php echo $error; ?></p>
            <?php endif; ?>

            <div class="input-group">
                <input type="email" name="user_email" placeholder="Email Address" pattern=".+@gmail\.com" title="Please use a Gmail address" required>
                <i class="fa-solid fa-envelope"></i>
            </div>
                        <div class="input-group">
                <input type="password" name="password" placeholder="Password" required>
                <i class="fa-solid fa-lock"></i>
            </div>

          <button type="submit" class="Login">login</button>
          <p class="signup-link" style="text-align: center; margin-top: 15px; color: #fff;">
                Don't have an account? <a href="CreateAccount.php" style="color: #3498db; text-decoration: none;">Sign up here</a>
          </p>

        </form>
    </div>
</body>
</html>

