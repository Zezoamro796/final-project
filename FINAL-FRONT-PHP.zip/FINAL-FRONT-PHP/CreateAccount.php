<?php
require_once '../final back end/config.php';
session_start();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = $_POST['full_name'] ?? '';
    $email = $_POST['user_email'] ?? '';
    $phone = $_POST['user_phone'] ?? '';
    $age = $_POST['user_age'] ?? '';
    $gender = $_POST['user_gender'] ?? '';
    $city = $_POST['user_city'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if ($password !== $confirm_password) {
        $error = "Passwords do not match!";
    } else {
        // Check if email already exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = "Email already registered!";
        } else {
            // Hash password and insert user
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (full_name, email, phone, age, gender, city, password) VALUES (?, ?, ?, ?, ?, ?, ?)");
            try {
                $stmt->execute([$full_name, $email, $phone, $age, $gender, $city, $hashed_password]);
                $success = "Account created successfully! <a href='login.php'>Login here</a>";
            } catch (PDOException $e) {
                $error = "Registration failed: " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - AI Secure Web</title>
    <link rel="stylesheet" href="CreateAccount.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
     <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400&display=swap" rel="stylesheet">
    <script src="CreateAccount.js" defer></script>

</head>
<body>
    <div class="CreateAccount-container">
        <form class="CreateAccount-form" method="POST" action="CreateAccount.php">
            <h2>Create Account</h2>
            <p>Join our AI-powered cybersecurity platform</p>

            <?php if ($error): ?>
                <p style="color: #ff4d4d; background: rgba(255, 77, 77, 0.1); padding: 10px; border-radius: 5px; margin-bottom: 15px;"><?php echo $error; ?></p>
            <?php endif; ?>

            <?php if ($success): ?>
                <p style="color: #4dff4d; background: rgba(77, 255, 77, 0.1); padding: 10px; border-radius: 5px; margin-bottom: 15px;"><?php echo $success; ?></p>
            <?php endif; ?>

            

<div class="input-group">
    <label for="reg-email">Name</label>
    <div class="field-wrapper">
        <input type="text" 
        name="full_name" placeholder="Full Name" required>
        <i class="fa-solid fa-user"></i>
    </div>
</div>           

<div class="input-group">
    <label for="reg-email">Email</label>
    <div class="field-wrapper">
    <input type="email" id="reg-email" 
    name="user_email" 
    placeholder="XXXXXXXX@gmail.com" required>
    <i class="fa-solid fa-envelope"></i>
    </div>
</div>

<div class="input-group">
    <label for="u_phone">Phone Number</label>
    <div class="field-wrapper">
        <input type="tel" id="u_phone" 
        name="user_phone" 
        placeholder="01XXXXXXXXX" required>
        <i class="fa-solid fa-phone"></i>
    </div>
</div>

<div class="row">
    <div class="input-group">
        <div class="field-wrapper">
            <input type="number" name="user_age"
             placeholder="Age" min="10" max="100" required>
            <i class="fa-solid fa-calendar-day"></i>
        </div>
    </div>

    <div class="input-group">
        <div class="field-wrapper">
            <select name="user_gender" id="gender-select" required>
                <option value="" disabled selected>Gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                </select>
            <i class="fa-solid fa-user-tag"></i>
        </div>
    </div>
</div>

   <div class="input-group">
    <label for="u_city">City / Governorate</label>
    <div class="field-wrapper">
        <select id="u_city" name="user_city" required>
         <option value="" disabled selected>Select your City</option>
<option value="Damietta">Damietta</option>
<option value="Mansoura">Mansoura</option>
<option value="Port Said">Port Said</option>
<option value="Cairo">Cairo</option>
<option value="Giza">Giza</option>
<option value="Alexandria">Alexandria</option>
<option value="Qalyubia">Qalyubia</option>
<option value="Suez">Suez</option>
<option value="Ismailia">Ismailia</option>
<option value="Sharqia">Sharqia</option>
<option value="Gharbia">Gharbia</option>
<option value="Kafr El Sheikh">Kafr El Sheikh</option>
<option value="Monufia">Monufia</option>
<option value="Beheira">Beheira</option>
<option value="Fayoum">Fayoum</option>
<option value="Beni Suef">Beni Suef</option>
<option value="Minya">Minya</option>
<option value="Assiut">Assiut</option>
<option value="Sohag">Sohag</option>
<option value="Qena">Qena</option>
<option value="Luxor">Luxor</option>
<option value="Aswan">Aswan</option>
<option value="Red Sea">Red Sea</option>
<option value="New Valley">New Valley</option>
<option value="Matrouh">Matrouh</option>
<option value="North Sinai">North Sinai</option>
<option value="South Sinai">South Sinai</option>
            </select>
            <i class="fa-solid fa-location-dot"></i>
    </div>
</div>

         <div class="input-group">
    <label for="u_pass">Password</label>
    <div class="field-wrapper">
        <input type="password" id="u_pass" 
        name="password" placeholder="*********" required>
        <i class="fa-solid fa-eye-slash toggle-password"></i>
    </div>
</div>

<div class="input-group">
    <label for="u_confirm">Confirm Password</label>
    <div class="field-wrapper">
        <input type="password" id="u_confirm" 
        name="confirm_password" placeholder="*********" required>
        <i class="fa-solid fa-eye-slash toggle-password"></i>
    </div>
</div>

   <button type="submit" class="signup-btn" id="submit-btn">
                <span>Create Account</span>
                <i class="fa-solid fa-arrow-right"></i> </button>
                <p class="login-link">
                Already have an account ? 
               <a href="login.php">Login here</a>
            </p>
        </form>
    </div>
</body>

</html>